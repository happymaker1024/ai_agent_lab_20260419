from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_sports import (
    get_injury_report_data,
    get_player_stats_data,
    get_team_schedule_data,
)
from common.utils import print_panel


def build_assistant_view(team_name: str, player_name: str) -> str:
    return "\n".join(
        [
            f"[일정] {len(get_team_schedule_data(team_name))}건",
            f"[선수] {get_player_stats_data(player_name)}",
            f"[부상] {len(get_injury_report_data(team_name))}건",
        ]
    )


if __name__ == "__main__":
    print_panel("Sports Assistant App", build_assistant_view("서울 FC", "정우성"))
