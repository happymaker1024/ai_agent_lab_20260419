# AI Agent Lab

스포츠와 헬스케어 두 도메인으로 AI Agent 개념을 단계적으로 실습하는 예제 모음입니다.

## 폴더 구조

```text
ai-agent-lab/
├─ pyproject.toml
├─ uv.lock
├─ .python-version
├─ .env.example
├─ README.md
├─ data/
├─ common/
├─ chapters/
└─ apps/
```

## 환경 준비

```powershell
uv sync
Copy-Item .env.example .env
```

`.env` 파일에 OpenAI API 키를 넣으면 1장과 4장의 LLM 예제를 바로 실행할 수 있습니다.

## 챕터별 실습

### 1장. AI Agent 개념
- 스포츠: [sports_chatbot.py](D:\ai_agent_lab\ch01\chapters\ch01_intro\sports_chatbot.py)
- 스포츠: [sports_agent.py](D:\ai_agent_lab\ch01\chapters\ch01_intro\sports_agent.py)
- 헬스케어: [healthcare_chatbot.py](D:\ai_agent_lab\ch01\chapters\ch01_intro\healthcare_chatbot.py)
- 헬스케어: [healthcare_agent.py](D:\ai_agent_lab\ch01\chapters\ch01_intro\healthcare_agent.py)

### 2장. 왜 지금 AI Agent인가
- 스포츠: [sports_ops_assistant.py](D:\ai_agent_lab\ch01\chapters\ch02_why_agents_now\sports_ops_assistant.py)
- 헬스케어: [healthcare_ops_assistant.py](D:\ai_agent_lab\ch01\chapters\ch02_why_agents_now\healthcare_ops_assistant.py)

### 3장. Agent 아키텍처
- 스포츠: [sports_architecture.py](D:\ai_agent_lab\ch01\chapters\ch03_architecture\sports_architecture.py)
- 헬스케어: [healthcare_architecture.py](D:\ai_agent_lab\ch01\chapters\ch03_architecture\healthcare_architecture.py)

### 4장. LangChain vs LangGraph
- 스포츠: [sports_langchain_agent.py](D:\ai_agent_lab\ch01\chapters\ch04_langchain_vs_langgraph\sports_langchain_agent.py)
- 헬스케어: [healthcare_langgraph_approval.py](D:\ai_agent_lab\ch01\chapters\ch04_langchain_vs_langgraph\healthcare_langgraph_approval.py)

### 5장. 모델 + 도구 + 상태
- 스포츠: [sports_state_demo.py](D:\ai_agent_lab\ch01\chapters\ch05_model_tool_state\sports_state_demo.py)
- 헬스케어: [healthcare_state_demo.py](D:\ai_agent_lab\ch01\chapters\ch05_model_tool_state\healthcare_state_demo.py)

### 6장. Tool Calling
- 스포츠: [sports_tool_calling.py](D:\ai_agent_lab\ch01\chapters\ch06_tool_calling\sports_tool_calling.py)
- 헬스케어: [healthcare_tool_calling.py](D:\ai_agent_lab\ch01\chapters\ch06_tool_calling\healthcare_tool_calling.py)

### 7장. State와 Memory
- 스포츠: [sports_memory_demo.py](D:\ai_agent_lab\ch01\chapters\ch07_state_memory\sports_memory_demo.py)
- 헬스케어: [healthcare_memory_demo.py](D:\ai_agent_lab\ch01\chapters\ch07_state_memory\healthcare_memory_demo.py)

### 8장. HITL
- 스포츠: [sports_hitl_mail.py](D:\ai_agent_lab\ch01\chapters\ch08_hitl\sports_hitl_mail.py)
- 헬스케어: [healthcare_hitl_review.py](D:\ai_agent_lab\ch01\chapters\ch08_hitl\healthcare_hitl_review.py)

### 9장. Workflow vs Autonomous
- 스포츠: [sports_workflow_vs_autonomous.py](D:\ai_agent_lab\ch01\chapters\ch09_workflow_vs_autonomous\sports_workflow_vs_autonomous.py)
- 헬스케어: [healthcare_workflow_vs_autonomous.py](D:\ai_agent_lab\ch01\chapters\ch09_workflow_vs_autonomous\healthcare_workflow_vs_autonomous.py)

### 10장. 멀티에이전트
- 스포츠: [sports_multi_agent.py](D:\ai_agent_lab\ch01\chapters\ch10_multi_agent\sports_multi_agent.py)
- 헬스케어: [healthcare_multi_agent.py](D:\ai_agent_lab\ch01\chapters\ch10_multi_agent\healthcare_multi_agent.py)

### 11장. Agentic RAG
- 스포츠: [sports_agentic_rag.py](D:\ai_agent_lab\ch01\chapters\ch11_agentic_rag\sports_agentic_rag.py)
- 헬스케어: [healthcare_agentic_rag.py](D:\ai_agent_lab\ch01\chapters\ch11_agentic_rag\healthcare_agentic_rag.py)

## 실행 예시

```powershell
uv run --active python .\chapters\ch02_why_agents_now\sports_ops_assistant.py
uv run --active python .\chapters\ch06_tool_calling\healthcare_tool_calling.py
uv run --active python .\apps\sports_assistant.py
```

## 데이터 안내

- `data/sports/teams.csv`: 팀 기본 정보
- `data/sports/players.csv`: 선수 기록
- `data/sports/matches.csv`: 경기 일정
- `data/sports/injury_reports.csv`: 부상 리포트
- `data/healthcare/patients_mock.csv`: 합성 환자 기본 정보
- `data/healthcare/vitals_mock.csv`: 바이탈 정보
- `data/healthcare/appointments_mock.csv`: 예약 정보
- `data/healthcare/care_guidelines.md`: 생활관리 안내 문서

의료 데이터는 교육용 mock 데이터이며 실제 진단이나 처방에는 사용할 수 없습니다.
