from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langchain.agents import create_agent
from rich import print

from common.config import ensure_openai_api_key, get_model_name
from common.tools_healthcare import get_appointment_info, list_patients

SYSTEM_PROMPT = """
너는 예약 조회 에이전트다.
- 사용자가 예약을 확인해달라고 하면 반드시 도구를 사용한다.
- 환자 이름이 불명확하면 list_patients를 먼저 사용한다.
- 실제 데이터만 전달하고 의료 진단은 하지 않는다.
""".strip()


def main() -> None:
    ensure_openai_api_key()
    agent = create_agent(
        model=f"openai:{get_model_name()}",
        tools=[list_patients, get_appointment_info],
        system_prompt=SYSTEM_PROMPT,
    )
    user_input = input("질문을 입력하세요 [예: 김민수 예약 확인해줘]: ").strip()
    user_input = user_input or "김민수 예약 확인해줘"
    result = agent.invoke({"messages": [{"role": "user", "content": user_input}]})
    print("\n[bold green]=== 헬스케어 에이전트 응답 ===[/bold green]")
    for msg in result["messages"]:
        if getattr(msg, "type", "") == "ai":
            text = msg.text() if hasattr(msg, "text") else str(msg.content)
            if text:
                print(text)


if __name__ == "__main__":
    main()
