from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langchain_openai import ChatOpenAI
from rich import print

from common.config import ensure_openai_api_key, get_model_name

PROMPT = """
너는 축구 일반 안내 챗봇이다.
- 실제 내부 CSV 데이터에는 접근할 수 없다.
- 일정이나 선수 기록을 직접 확인해달라는 요청에는 제한을 솔직히 설명한다.
- 대신 사용자가 어떤 정보를 준비하면 좋은지 짧고 정확하게 안내한다.
""".strip()


def main() -> None:
    ensure_openai_api_key()
    model = ChatOpenAI(model=get_model_name(), temperature=0)
    user_input = input("질문을 입력하세요 [예: 서울 FC 경기 일정 알려줘]: ").strip()
    user_input = user_input or "서울 FC 경기 일정 알려줘"
    response = model.invoke(
        [
            {"role": "system", "content": PROMPT},
            {"role": "user", "content": user_input},
        ]
    )
    print("\n[bold cyan]=== 스포츠 챗봇 응답 ===[/bold cyan]")
    print(response.text())


if __name__ == "__main__":
    main()
