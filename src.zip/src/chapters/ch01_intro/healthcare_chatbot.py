from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langchain_openai import ChatOpenAI
from rich import print

from common.config import ensure_openai_api_key, get_model_name

PROMPT = """
너는 예약 안내 챗봇이다.
- 실제 예약 CSV나 환자 바이탈 데이터에는 접근할 수 없다.
- 실제 예약 확인 요청에는 직접 확인할 수 없다고 설명한다.
- 필요한 정보와 문의 방법은 짧게 안내한다.
""".strip()


def main() -> None:
    ensure_openai_api_key()
    model = ChatOpenAI(model=get_model_name(), temperature=0)
    user_input = input("질문을 입력하세요 [예: 김민수 예약 확인해줘]: ").strip()
    user_input = user_input or "김민수 예약 확인해줘"
    response = model.invoke(
        [
            {"role": "system", "content": PROMPT},
            {"role": "user", "content": user_input},
        ]
    )
    print("\n[bold cyan]=== 헬스케어 챗봇 응답 ===[/bold cyan]")
    print(response.text())


if __name__ == "__main__":
    main()
