"""Chapter 1 examples."""
