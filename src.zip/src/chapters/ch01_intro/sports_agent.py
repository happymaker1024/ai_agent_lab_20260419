from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langchain.agents import create_agent
from rich import print

from common.config import ensure_openai_api_key, get_model_name
from common.tools_sports import get_team_schedule, list_soccer_teams

SYSTEM_PROMPT = """
너는 축구 일정 조회 에이전트다.
- 사용자가 실제 경기 일정을 물으면 반드시 도구를 사용한다.
- 팀명을 모르면 list_soccer_teams를 먼저 호출한다.
- 답변은 한국어로 짧고 정확하게 한다.
""".strip()


def main() -> None:
    ensure_openai_api_key()
    agent = create_agent(
        model=f"openai:{get_model_name()}",
        tools=[list_soccer_teams, get_team_schedule],
        system_prompt=SYSTEM_PROMPT,
    )
    user_input = input("질문을 입력하세요 [예: 서울 FC 경기 일정 알려줘]: ").strip()
    user_input = user_input or "서울 FC 경기 일정 알려줘"
    result = agent.invoke({"messages": [{"role": "user", "content": user_input}]})
    print("\n[bold green]=== 스포츠 에이전트 응답 ===[/bold green]")
    for msg in result["messages"]:
        if getattr(msg, "type", "") == "ai":
            text = msg.text() if hasattr(msg, "text") else str(msg.content)
            if text:
                print(text)


if __name__ == "__main__":
    main()
