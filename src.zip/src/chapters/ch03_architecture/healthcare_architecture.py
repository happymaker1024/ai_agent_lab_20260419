from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel

MERMAID = """
flowchart TD
    U[환자 요청] --> M[Patient Summary Agent]
    M --> A1[예약 조회 도구]
    M --> A2[바이탈 조회 도구]
    M --> A3[케어 가이드 검색]
    A1 --> S[State: patient summary]
    A2 --> S
    A3 --> S
    S --> H[필요 시 사람 검토]
    H --> R[요약 응답]
""".strip()


if __name__ == "__main__":
    print_panel("3장 헬스케어 Agent 아키텍처", MERMAID)
