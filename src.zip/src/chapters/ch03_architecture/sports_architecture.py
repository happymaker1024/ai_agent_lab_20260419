from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel

MERMAID = """
flowchart LR
    U[사용자 질문] --> M[Model]
    M --> T[Tools: schedule / player / injury]
    T --> S[State: last_team / notes]
    S --> A[Approval: 외부 공유 전 검토]
    A --> R[최종 응답]
""".strip()


if __name__ == "__main__":
    print_panel("3장 스포츠 Agent 아키텍처", MERMAID)
