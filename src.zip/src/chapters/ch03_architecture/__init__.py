"""Chapter 3 examples."""
