from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


@dataclass
class DirectAPIClient:
    def get_calendar_events(self, user_id: str) -> str:
        return f"{user_id}의 외부 캘린더 이벤트 2건"


@dataclass
class MCPServer:
    label: str

    def read_resource(self, uri: str) -> str:
        return f"{uri}에서 읽은 팀 운영 정책 문서"

    def call_tool(self, name: str, user_id: str) -> str:
        return f"{name} 호출 결과: {user_id}의 외부 캘린더 이벤트 2건"


def compare_flows() -> str:
    direct = DirectAPIClient()
    mcp = MCPServer(label="calendar-mcp")
    direct_result = direct.get_calendar_events("coach-001")
    resource_text = mcp.read_resource("resource://policy/meeting-rules")
    mcp_result = mcp.call_tool("calendar.list_events", user_id="coach-001")
    lines = [
        "[기존 API 호출 방식]",
        f"- 개발자가 API 메서드를 직접 안다: {direct_result}",
        "",
        "[MCP 연동 방식]",
        f"- 에이전트가 리소스 문맥을 읽음: {resource_text}",
        f"- 에이전트가 서버의 표준 도구를 호출함: {mcp_result}",
        "",
        "차이",
        "- 기존 방식은 엔드포인트와 인증 구조를 애플리케이션이 직접 강하게 안다.",
        "- MCP 방식은 서버가 공개한 도구/리소스 계층을 통해 더 느슨하게 연결된다.",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("20장 MCP 연동 Agent", compare_flows())

