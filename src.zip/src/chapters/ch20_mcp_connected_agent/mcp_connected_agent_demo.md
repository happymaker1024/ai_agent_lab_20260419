# mcp_connected_agent_demo 예제 설명

## 파일

- 대상 코드: `mcp_connected_agent_demo.py`

## 학습 목표

- MCP 연동 agent의 최소 구조를 이해한다.
- 외부 리소스 읽기와 외부 도구 호출을 한 흐름으로 묶는 법을 파악한다.
- 기존 API 호출 방식과 MCP 방식의 차이를 비교할 수 있다.

## Mermaid로 보는 흐름

```mermaid
flowchart LR
    A["Agent"] --> B["MCP Server"]
    B --> C["Read Resource"]
    B --> D["Call Tool"]
    C --> E["문맥 연결"]
    D --> F["외부 동작 결과"]
    E --> G["통합 응답"]
    F --> G
```

## 기존 API 방식과 비교

```mermaid
flowchart TD
    A["직접 API 호출"] --> B["앱이 엔드포인트/인증/응답 구조를 직접 안다"]
    C["MCP 연동"] --> D["표준화된 tool/resource 계층을 통해 연결한다"]
```

## 예제 설명

이 예제는 실습 4에 해당한다.

- 외부 리소스 읽기
- 외부 도구 호출
- 문맥과 동작을 MCP 기반으로 연결
- 기존 API 호출 방식과 비교

실제 원격 MCP 서버 대신 로컬 클래스로 개념을 단순화했지만, 강의에서 설명해야 할 핵심 차이는 그대로 담고 있다.

## 실행 방법

```powershell
python mcp_connected_agent_demo.py
```

## 코드 포인트

- `DirectAPIClient`는 전통적인 직접 연동 방식을 표현한다.
- `MCPServer`는 resource와 tool을 동시에 제공한다.
- 한 agent가 문맥 읽기와 동작 실행을 모두 MCP 계층에서 처리하는 그림을 보여준다.

## 공식 자료 메모

OpenAI 공식 도구 문서에서는 Responses API에서 remote MCP server를 tool로 연결할 수 있고, MCP 서버의 tool 목록을 읽고 필요 시 approval을 거쳐 호출하는 흐름을 설명한다.

## 참고 링크

- [OpenAI MCP and Connectors](https://developers.openai.com/api/docs/guides/tools-connectors-mcp)
- [OpenAI Docs MCP](https://developers.openai.com/learn/docs-mcp)
- [Building MCP servers for ChatGPT and API integrations](https://platform.openai.com/docs/mcp/)

