# sports_tool_calling 예제 설명

## 파일

- 대상 코드: `sports_tool_calling.py`

## 학습 목표

- tool을 직접 호출해 결과를 조합하는 기본 패턴을 익힌다.
- 에이전트 없이도 tool orchestration 개념을 이해한다.

## 예제 설명

이 예제는 두 개의 도구를 순서대로 호출한다.

- `get_team_schedule`
- `get_player_stats`

결과는 하나의 문자열로 합쳐져 출력된다.  
즉, "무엇을 호출할지"를 모델이 결정하는 대신 코드가 명시적으로 orchestration을 수행한다.

## 실행 방법

```powershell
python sports_tool_calling.py
```

## 코드 포인트

- tool의 `.invoke()`를 직접 사용한다.
- 두 결과를 이어 붙여 패널 형태로 출력한다.

## 관찰 포인트

- tool calling은 반드시 자율 에이전트일 필요는 없다.
- 먼저 직접 호출 패턴을 이해하면 이후 agent tool use도 쉬워진다.

## 실습 질문

- 세 번째 도구인 부상 조회를 추가하면 출력 형식을 어떻게 바꾸고 싶은가?
- 모델이 자동으로 tool을 선택하는 방식과 코드가 고정으로 호출하는 방식의 차이는 무엇인가?

