from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_healthcare import get_appointment_info, get_patient_vitals
from common.utils import print_panel


if __name__ == "__main__":
    body = "\n\n".join(
        [
            get_appointment_info.invoke({"patient_name": "김민수"}),
            get_patient_vitals.invoke({"patient_name": "김민수"}),
        ]
    )
    print_panel("6장 헬스케어 Tool Calling", body)
