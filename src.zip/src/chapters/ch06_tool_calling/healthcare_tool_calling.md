# healthcare_tool_calling 예제 설명

## 파일

- 대상 코드: `healthcare_tool_calling.py`

## 학습 목표

- 헬스케어 정보를 tool 호출로 결합하는 방식을 익힌다.
- 예약 정보와 바이탈 정보를 함께 보여주는 패턴을 이해한다.

## 예제 설명

이 예제는 한 환자에 대해 두 개의 도구를 직접 호출한다.

- `get_appointment_info`
- `get_patient_vitals`

결과는 패널 형태로 합쳐져 출력된다.  
상담 전 요약이나 직원 확인 화면의 초기 버전으로 생각해볼 수 있다.

## 실행 방법

```powershell
python healthcare_tool_calling.py
```

## 코드 포인트

- 도구를 `.invoke()`로 직접 실행한다.
- 예약과 바이탈처럼 서로 다른 타입의 정보를 같은 뷰로 결합한다.

## 관찰 포인트

- 에이전트 이전 단계에서도 업무형 화면을 만들 수 있다.
- 여러 tool을 연결하는 설계가 곧 작은 workflow가 된다.

## 실습 질문

- 세 번째 tool로 생활관리 가이드를 추가한다면 어떤 순서가 좋을까?
- 결과를 bullet 요약으로 바꾸면 어떤 장점이 있을까?

