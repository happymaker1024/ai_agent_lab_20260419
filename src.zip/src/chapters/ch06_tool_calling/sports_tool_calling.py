from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_sports import get_player_stats, get_team_schedule
from common.utils import print_panel


if __name__ == "__main__":
    body = "\n\n".join(
        [
            get_team_schedule.invoke({"team_name": "서울 FC"}),
            get_player_stats.invoke({"player_name": "정우성"}),
        ]
    )
    print_panel("6장 스포츠 Tool Calling", body)
