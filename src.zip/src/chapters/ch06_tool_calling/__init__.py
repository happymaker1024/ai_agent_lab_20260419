"""Chapter 6 examples."""
