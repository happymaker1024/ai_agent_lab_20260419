# agent_ops_runbook 예제 설명

## 파일

- 대상 코드: `agent_ops_runbook.py`

## 학습 목표

- 개발용 agent와 운영용 agent의 차이를 이해한다.
- 장애 대응, 재실행, 비용 통제, 권한과 보안의 중요성을 파악한다.

## Mermaid로 보는 운영 관점

```mermaid
flowchart LR
    A["Agent Run"] --> B["State / Checkpoint"]
    A --> C["Logs / Traces"]
    A --> D["Budget Control"]
    A --> E["Approval / Permissions"]
    B --> F["중단 후 재실행"]
    C --> G["장애 분석"]
    D --> H["비용 통제"]
    E --> I["안전한 배포"]
```

## 예제 설명

이 예제는 tool timeout이 발생한 운영 상황을 가정하고, 재실행 전에 무엇을 확인해야 하는지 runbook 형태로 보여준다.

- 체크포인트 저장 여부
- 남은 재시도 횟수
- 예산 잔액
- 승인 필요 여부
- 로그 추적 확인

즉, 운영용 agent는 "잘 동작할 때"보다 "문제가 생겼을 때 어떻게 버틸지"가 중요하다.

## 실행 방법

```powershell
python agent_ops_runbook.py
```

## 코드 포인트

- `OpsState`는 운영 관점의 최소 상태를 담는다.
- 실패 후 복구 판단 로직을 별도 함수로 분리했다.
- 예산, 권한, checkpoint를 같은 레벨의 운영 요소로 취급한다.

## 강의 포인트

- 개발용 vs 운영용:
  운영용은 재개 가능성, 추적 가능성, 비용 한도, 권한 경계가 필수다.
- 안전한 배포:
  read-only 시작, approval 기본값 강화, rollout 점진 적용이 좋다.

## 참고 링크

- [LangGraph Persistence](https://docs.langchain.com/oss/python/langgraph/persistence)
- [LangGraph Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)
- [OpenAI Tracing](https://openai.github.io/openai-agents-python/tracing/)
- [OpenAI Guardrails](https://openai.github.io/openai-agents-python/guardrails/)

