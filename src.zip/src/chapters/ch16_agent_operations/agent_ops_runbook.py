from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


@dataclass
class OpsState:
    run_id: str
    status: str
    retries_left: int
    budget_left_usd: float
    approval_required: bool
    checkpoint_saved: bool


def recover_after_failure(state: OpsState) -> list[str]:
    lines = [f"run_id={state.run_id}", f"status={state.status}"]
    if state.checkpoint_saved:
        lines.append("체크포인트에서 재시작 가능")
    if state.retries_left > 0:
        lines.append(f"남은 재시도: {state.retries_left}회")
    if state.budget_left_usd <= 0.01:
        lines.append("비용 한도 경고: 저비용 모델 또는 사람 이관 필요")
    if state.approval_required:
        lines.append("승인 필요: 민감 작업은 자동 재실행 금지")
    lines.append("추적 로그 확인 후 재실행 결정")
    return lines


if __name__ == "__main__":
    demo = OpsState(
        run_id="run-2026-04-19-001",
        status="tool_timeout",
        retries_left=1,
        budget_left_usd=0.008,
        approval_required=True,
        checkpoint_saved=True,
    )
    print_panel("16장 운영 관점의 Agent", "\n".join(recover_after_failure(demo)))

