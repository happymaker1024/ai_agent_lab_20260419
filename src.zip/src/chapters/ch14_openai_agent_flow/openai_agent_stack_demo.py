from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


def build_stack_summary() -> str:
    lines = [
        "OpenAI 기준 최신 Agent 개발 흐름 요약",
        "1. Responses API: 상태형, 멀티모달, tool-using 인터페이스",
        "2. Agents SDK: 코드 중심 orchestration, handoff, tracing",
        "3. Tools: function calling / remote MCP / web search / file search",
        "4. Guardrails: 입력/출력/도구 경계 검증",
        "5. Results and State: 응답, 사용량, 승인, 재개 상태 추적",
        "6. Observability: tracing과 workflow 가시성",
        "7. Evaluate agent workflows: 품질 검증 루프",
        "8. Sandbox agent: 격리된 실행 환경을 활용하는 에이전트 패턴",
        "",
        "권장 학습 흐름",
        "- 단일 Responses API 호출 이해",
        "- tool calling 추가",
        "- state와 결과 추적 도입",
        "- guardrails와 observability 추가",
        "- eval로 개선 루프 구축",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("14장 OpenAI 최신 Agent 개발 흐름", build_stack_summary())

