# openai_agent_stack_demo 예제 설명

## 파일

- 대상 코드: `openai_agent_stack_demo.py`

## 학습 목표

- OpenAI 기준 최신 agent 개발 흐름을 큰 그림으로 이해한다.
- Responses API와 Agents SDK의 역할 차이를 설명할 수 있다.
- Tools, Guardrails, Results/State, Observability, Eval의 연결 관계를 파악한다.

## Mermaid로 보는 전체 흐름

```mermaid
flowchart LR
    A["User Input"] --> B["Responses API"]
    B --> C["Tools"]
    C --> D["Results and State"]
    D --> E["Guardrails"]
    E --> F["Observability / Tracing"]
    F --> G["Evaluation"]
    G --> H["개선된 Agent Workflow"]
```

## 예제 설명

이 예제는 실제 API 호출 대신 OpenAI 공식 문서 기준 최신 구성요소를 한 화면에 요약해준다.

- Responses API를 기본 실행 인터페이스로 본다.
- Agents SDK는 코드 중심 orchestration 경로로 본다.
- Guardrails, state, tracing, eval이 운영 품질을 만든다는 점을 강조한다.

## 구성 요소 한눈에 보기

```mermaid
flowchart TD
    A["Responses API"] --> B["Tool 사용"]
    A --> C["Conversation / previous_response_id"]
    D["Agents SDK"] --> E["Handoffs"]
    D --> F["Tracing"]
    D --> G["Guardrails"]
    D --> H["Results and State"]
```

## 실행 방법

```powershell
python openai_agent_stack_demo.py
```

## 강의 포인트

- Responses API:
  agent-like application용 통합 인터페이스
- Agents SDK:
  코드 중심 orchestration과 trace 관리
- Sandbox agent:
  안전한 격리 실행 도구나 컨테이너 기반 agent 패턴으로 이해하면 좋다

## 공식 자료 메모

2026-04-19 기준 OpenAI 공식 문서 네비게이션에는 `Responses API`, `Agents SDK`, `Guardrails`, `Results and state`, `Integrations and observability`, `Evaluate agent workflows`, `Sandbox agents`가 모두 별도 항목으로 정리되어 있다.

## 참고 링크

- [OpenAI API Overview](https://developers.openai.com/api/reference/overview)
- [Responses API](https://platform.openai.com/docs/api-reference/responses/retrieve)
- [Using tools](https://platform.openai.com/docs/guides/tools?api-mode=responses)
- [Agents SDK](https://platform.openai.com/docs/guides/agents-sdk/)
- [Guardrails](https://openai.github.io/openai-agents-python/guardrails/)
- [Results and state](https://openai.github.io/openai-agents-python/results/)
- [Tracing](https://openai.github.io/openai-agents-python/tracing/)
- [Working with evals](https://platform.openai.com/docs/guides/evals)

