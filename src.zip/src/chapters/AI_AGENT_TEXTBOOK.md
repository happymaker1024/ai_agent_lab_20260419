# AI Agent 실습 교재

## 교재 소개

이 교재는 현재 저장소의 `ch01_intro`부터 `ch11_agentic_rag`까지의 예제를 바탕으로 구성한 AI Agent 입문 실습서다.  
목표는 단순한 챗봇을 넘어서, 도구를 호출하고 상태를 기억하며, 사람의 승인과 여러 에이전트 협업까지 다루는 실전형 에이전트의 구조를 이해하는 것이다.

이 저장소는 두 개의 도메인을 반복해서 사용한다.

- 스포츠 도메인: 경기 일정, 선수 기록, 부상 리포트
- 헬스케어 도메인: 예약 확인, 메시지 발송, 검토 승인

같은 구조를 도메인만 바꿔 반복하기 때문에, 학습자는 "에이전트 패턴" 자체에 집중하기 좋다.

---

## 학습 목표

이 교재를 마치면 다음을 설명하고 구현할 수 있다.

- 챗봇과 에이전트의 차이
- 모델, 도구, 상태, 메모리의 역할
- Tool Calling과 상태 기반 응답 흐름
- Human-in-the-Loop(HITL)가 왜 필요한지
- Workflow 방식과 Autonomous 방식의 차이
- Multi-Agent와 Agentic RAG의 기본 구조

---

## 전체 로드맵

| 장 | 폴더 | 핵심 주제 |
|---|---|---|
| 1장 | `ch01_intro` | 챗봇 vs 에이전트 |
| 2장 | `ch02_why_agents_now` | 왜 지금 에이전트인가 |
| 3장 | `ch03_architecture` | 에이전트 아키텍처 |
| 4장 | `ch04_langchain_vs_langgraph` | LangChain과 LangGraph 비교 |
| 5장 | `ch05_model_tool_state` | 모델, 도구, 상태 |
| 6장 | `ch06_tool_calling` | Tool Calling 실습 |
| 7장 | `ch07_state_memory` | 상태와 메모리 |
| 8장 | `ch08_hitl` | Human-in-the-Loop |
| 9장 | `ch09_workflow_vs_autonomous` | Workflow vs Autonomous |
| 10장 | `ch10_multi_agent` | 멀티 에이전트 협업 |
| 11장 | `ch11_agentic_rag` | Agentic RAG |

---

## AI Agent란 무엇인가

AI Agent는 단순히 답변만 생성하는 모델이 아니라, 목표를 달성하기 위해 도구를 사용하고 현재 상태를 반영하며 필요하면 사람의 승인을 받고, 여러 단계를 거쳐 행동하는 시스템이다.

### 챗봇과 에이전트 비교

| 항목 | 챗봇 | AI Agent |
|---|---|---|
| 응답 방식 | 학습된 지식 기반 답변 | 목표 기반 행동과 답변 |
| 외부 데이터 조회 | 보통 불가 | 가능 |
| 도구 사용 | 거의 없음 | 적극 사용 |
| 상태 유지 | 약함 | 강함 |
| 승인 절차 | 드묾 | 중요 상황에서 필요 |

### 개념 시각화

```mermaid
flowchart LR
    U["사용자 요청"] --> M["모델(LLM)"]
    M --> P["계획 수립"]
    P --> T["도구 호출"]
    T --> S["상태 업데이트"]
    S --> H["사람 승인 여부 확인"]
    H --> R["최종 응답 또는 행동"]
```

---

## 1장. 챗봇 vs 에이전트

### 폴더 구성

- `ch01_intro/sports_chatbot.py`
- `ch01_intro/sports_agent.py`
- `ch01_intro/healthcare_chatbot.py`
- `ch01_intro/healthcare_agent.py`
- `ch01_intro/LAB_GUIDE.md`

### 핵심 개념

1장의 핵심은 "말만 하는 시스템"과 "행동하는 시스템"의 차이다.

- 챗봇은 설명은 잘하지만 실제 데이터 조회를 직접 하지 못한다.
- 에이전트는 질문을 받으면 필요한 도구를 골라 실제 데이터를 조회한 뒤 응답한다.

`sports_agent.py`에서는 경기 일정 질문이 들어오면 `list_soccer_teams`, `get_team_schedule` 같은 도구를 사용하도록 설계되어 있다.  
즉, 에이전트는 모르는 것을 추측하지 않고 필요한 도구를 먼저 사용한다.

### 개념 시각화

```mermaid
flowchart TD
    A["사용자: 서울 FC 경기 일정 알려줘"] --> B["챗봇"]
    A --> C["에이전트"]
    B --> D["일반 설명 또는 한계 안내"]
    C --> E["일정 조회 도구 호출"]
    E --> F["실제 일정 데이터 획득"]
    F --> G["정확한 답변 생성"]
```

### 실습

```powershell
python ch01_intro\sports_agent.py
python ch01_intro\healthcare_agent.py
```

### 실습 질문

- 챗봇은 왜 정확한 일정이나 예약을 주지 못하는가?
- 에이전트는 어떤 순간에 tool을 호출하는가?
- 같은 질문을 두 번 넣었을 때 응답이 어떻게 달라지는가?

---

## 2장. 왜 지금 에이전트인가

### 폴더 구성

- `ch02_why_agents_now/sports_ops_assistant.py`
- `ch02_why_agents_now/healthcare_ops_assistant.py`

### 핵심 개념

이 장은 에이전트가 필요한 배경을 설명한다.  
현업의 문제는 단순 Q&A가 아니라 다음처럼 여러 데이터 조각을 모아 판단해야 한다.

- 경기 일정 확인
- 선수 상태 요약
- 부상 정보 반영
- 예약 정보 확인
- 메시지 초안 생성

`sports_ops_assistant.py`는 일정, 선수 기록, 부상 데이터를 한 번에 묶어서 운영 보고서 형태로 요약한다.  
즉, 에이전트는 "한 번의 답변"보다 "업무 조합"에 더 적합하다.

### 개념 시각화

```mermaid
flowchart LR
    A["운영 질문"] --> B["일정 데이터"]
    A --> C["선수 데이터"]
    A --> D["부상 데이터"]
    B --> E["에이전트 통합 판단"]
    C --> E
    D --> E
    E --> F["업무형 보고서"]
```

### 실습

```powershell
python ch02_why_agents_now\sports_ops_assistant.py
python ch02_why_agents_now\healthcare_ops_assistant.py
```

### 정리

에이전트가 필요한 이유는 모델이 똑똑해졌기 때문만이 아니라, 실제 업무가 여러 도구와 단계를 요구하기 때문이다.

---

## 3장. 에이전트 아키텍처

### 폴더 구성

- `ch03_architecture/sports_architecture.py`
- `ch03_architecture/healthcare_architecture.py`

### 핵심 개념

이 장은 에이전트를 구성하는 큰 블록을 소개한다.

- User: 요청을 입력
- Model: 요청 이해와 다음 행동 결정
- Tools: 외부 데이터 조회 및 액션 실행
- State: 현재 문맥과 중간 결과 저장
- Approval: 민감한 동작 전 사람 검토
- Response: 최종 결과 반환

저장소의 예제는 이를 Mermaid 다이어그램으로 직접 보여준다.

### 개념 시각화

```mermaid
flowchart LR
    U["User"] --> M["Model"]
    M --> T["Tools"]
    T --> S["State"]
    S --> A["Approval"]
    A --> R["Response"]
```

### 실습

```powershell
python ch03_architecture\sports_architecture.py
python ch03_architecture\healthcare_architecture.py
```

### 생각해보기

- 모든 요청에 Approval이 필요한가?
- State 없이 Tool만 있으면 충분한가?

---

## 4장. LangChain과 LangGraph 비교

### 폴더 구성

- `ch04_langchain_vs_langgraph/sports_langchain_agent.py`
- `ch04_langchain_vs_langgraph/healthcare_langgraph_approval.py`

### 핵심 개념

이 장은 두 프레임워크의 관점을 비교한다.

- LangChain: 빠르게 에이전트를 만들기 좋다.
- LangGraph: 상태와 흐름 제어가 중요한 경우 적합하다.

`sports_langchain_agent.py`는 `create_agent`를 사용해 비교적 짧은 코드로 도구 기반 에이전트를 만든다.  
반면 `healthcare_langgraph_approval.py`는 `prepare_message -> wait_for_approval -> finalize`의 명시적 흐름을 그래프로 정의한다.

### 비교표

| 항목 | LangChain | LangGraph |
|---|---|---|
| 목적 | 빠른 에이전트 구성 | 복잡한 흐름 제어 |
| 코드 스타일 | 간결함 | 명시적 상태 전이 |
| 적합한 상황 | 단순 Tool Agent | 승인, 분기, 반복 |

### 개념 시각화

```mermaid
flowchart LR
    A["간단한 질의응답"] --> B["LangChain"]
    C["승인/분기/반복이 있는 업무"] --> D["LangGraph"]
```

### 실습

```powershell
python ch04_langchain_vs_langgraph\sports_langchain_agent.py
python ch04_langchain_vs_langgraph\healthcare_langgraph_approval.py
```

### 실습 포인트

- 어떤 상황에서 그래프 기반 접근이 더 안전한가?
- 승인 단계가 끼어들면 왜 순차 그래프가 유리한가?

---

## 5장. 모델, 도구, 상태

### 폴더 구성

- `ch05_model_tool_state/sports_state_demo.py`
- `ch05_model_tool_state/healthcare_state_demo.py`

### 핵심 개념

에이전트의 핵심 3요소는 다음과 같다.

- 모델: 무엇을 할지 결정
- 도구: 실제 데이터나 기능을 제공
- 상태: 이전 결과와 문맥을 저장

`sports_state_demo.py`에서는 선수 정보를 조회한 뒤, `last_player`와 메모를 상태에 남겨 후속 질문에 연결한다.

### 개념 시각화

```mermaid
flowchart TD
    A["사용자 질문"] --> B["모델 판단"]
    B --> C["도구 호출"]
    C --> D["결과 획득"]
    D --> E["상태 저장"]
    E --> F["후속 질문에 문맥 반영"]
```

### 실습

```powershell
python ch05_model_tool_state\sports_state_demo.py
python ch05_model_tool_state\healthcare_state_demo.py
```

### 체크포인트

- 상태가 없다면 "이전 선수"를 기억할 수 있는가?
- 도구 결과를 상태에 남기는 이유는 무엇인가?

---

## 6장. Tool Calling

### 폴더 구성

- `ch06_tool_calling/sports_tool_calling.py`
- `ch06_tool_calling/healthcare_tool_calling.py`

### 핵심 개념

Tool Calling은 에이전트가 필요한 기능을 명시적으로 실행하는 과정이다.

- 팀 일정 조회
- 선수 기록 조회
- 예약 정보 확인
- 환자 관련 정보 확인

`sports_tool_calling.py`는 일정 조회와 선수 조회를 연속으로 호출해서 결과를 하나의 출력으로 묶는다.

### 개념 시각화

```mermaid
sequenceDiagram
    participant U as User
    participant A as Agent
    participant T1 as Schedule Tool
    participant T2 as Player Tool
    U->>A: 서울 FC와 정우성 정보 알려줘
    A->>T1: 팀 일정 조회
    T1-->>A: 일정 반환
    A->>T2: 선수 기록 조회
    T2-->>A: 기록 반환
    A-->>U: 통합 응답
```

### 실습

```powershell
python ch06_tool_calling\sports_tool_calling.py
python ch06_tool_calling\healthcare_tool_calling.py
```

### 확장 과제

- 새로운 tool을 하나 더 추가해보기
- 두 개 이상의 tool 결과를 표 형식으로 합쳐보기

---

## 7장. 상태와 메모리

### 폴더 구성

- `ch07_state_memory/sports_memory_demo.py`
- `ch07_state_memory/healthcare_memory_demo.py`

### 핵심 개념

상태(state)는 현재 실행 중 필요한 정보이고, 메모리(memory)는 이후 응답에도 계속 반영될 수 있는 선호나 기록이다.

`sports_memory_demo.py`는 `preference="EPL 요약 선호"`를 저장한 뒤, 다음 응답 전략을 바꾼다.  
즉, 메모리는 단순 기록이 아니라 응답 방식을 바꾸는 장치다.

### 상태와 메모리 비교

| 항목 | 상태 | 메모리 |
|---|---|---|
| 범위 | 현재 작업 중심 | 장기적 선호 반영 |
| 예시 | 마지막 조회 선수 | 요약 선호 리그 |
| 목적 | 문맥 유지 | 개인화 |

### 개념 시각화

```mermaid
flowchart LR
    A["사용자 선호 입력"] --> B["메모리 저장"]
    C["현재 질문"] --> D["상태 생성"]
    B --> E["응답 전략"]
    D --> E
    E --> F["개인화된 답변"]
```

### 실습

```powershell
python ch07_state_memory\sports_memory_demo.py
python ch07_state_memory\healthcare_memory_demo.py
```

### 토론 주제

- 메모리가 잘못 저장되면 어떤 문제가 생길까?
- 상태와 메모리를 분리하지 않으면 어떤 혼란이 생길까?

---

## 8장. Human-in-the-Loop(HITL)

### 폴더 구성

- `ch08_hitl/sports_hitl_mail.py`
- `ch08_hitl/healthcare_hitl_review.py`

### 핵심 개념

에이전트가 항상 바로 행동하면 위험할 수 있다.  
특히 외부 발송, 예약 변경, 고객 통보, 환자 안내 같은 일은 사람의 검토가 필요하다.

`sports_hitl_mail.py`는 메일 발송 전에 승인 여부를 묻는다.  
이 구조는 자동화보다 안전성을 우선하는 설계다.

### 개념 시각화

```mermaid
flowchart TD
    A["에이전트가 초안 생성"] --> B["사람 검토"]
    B -->|승인| C["실행"]
    B -->|보류| D["중단 또는 수정"]
```

### 실습

```powershell
python ch08_hitl\sports_hitl_mail.py
python ch08_hitl\healthcare_hitl_review.py
```

### 실습 질문

- 어떤 액션은 자동 실행해도 되고, 어떤 액션은 승인받아야 하는가?
- HITL은 정확도보다 무엇을 보장하려는 장치인가?

---

## 9장. Workflow vs Autonomous

### 폴더 구성

- `ch09_workflow_vs_autonomous/sports_workflow_vs_autonomous.py`
- `ch09_workflow_vs_autonomous/healthcare_workflow_vs_autonomous.py`

### 핵심 개념

이 장은 두 가지 운영 방식을 비교한다.

### Workflow 방식

- 정해진 순서로 실행
- 예측 가능성 높음
- 감사와 통제가 쉬움

### Autonomous 방식

- 필요하다고 판단한 추가 행동 수행
- 더 유연함
- 통제 장치가 없으면 위험할 수 있음

`sports_workflow_vs_autonomous.py`에서는 일정만 보고하는 정해진 절차와, 부상 리포트까지 추가 조사하는 자율 방식을 비교한다.

### 개념 시각화

```mermaid
flowchart LR
    A["입력"] --> B["Workflow"]
    A --> C["Autonomous"]
    B --> D["고정 단계 실행"]
    C --> E["상황에 따라 추가 조사"]
```

### 실습

```powershell
python ch09_workflow_vs_autonomous\sports_workflow_vs_autonomous.py
python ch09_workflow_vs_autonomous\healthcare_workflow_vs_autonomous.py
```

### 실무 해설

처음 시스템을 만들 때는 Workflow가 안전하다.  
이후 도메인 이해와 통제 장치가 충분해지면 Autonomous 성격을 점차 늘리는 것이 현실적이다.

---

## 10장. 멀티 에이전트

### 폴더 구성

- `ch10_multi_agent/sports_multi_agent.py`
- `ch10_multi_agent/healthcare_multi_agent.py`

### 핵심 개념

복잡한 업무를 하나의 거대한 에이전트가 모두 처리하는 대신, 역할을 나눠 여러 에이전트가 협업하도록 만들 수 있다.

`sports_multi_agent.py`는 다음과 같은 역할 분리를 보여준다.

- Research Agent: 일정 수집
- Stats Agent: 선수 정보 분석
- Summary Agent: 결과 통합

### 개념 시각화

```mermaid
flowchart TD
    A["사용자 요청"] --> B["Coordinator"]
    B --> C["Research Agent"]
    B --> D["Stats Agent"]
    C --> E["Summary Agent"]
    D --> E
    E --> F["최종 보고"]
```

### 실습

```powershell
python ch10_multi_agent\sports_multi_agent.py
python ch10_multi_agent\healthcare_multi_agent.py
```

### 실습 과제

- Agent를 하나 더 추가해 부상 분석 역할을 분리해보기
- Coordinator가 각 결과를 우선순위별로 정렬하게 바꿔보기

---

## 11장. Agentic RAG

### 폴더 구성

- `ch11_agentic_rag/sports_agentic_rag.py`
- `ch11_agentic_rag/healthcare_agentic_rag.py`

### 핵심 개념

RAG는 검색된 문서를 바탕으로 답변하는 구조다.  
Agentic RAG는 여기서 한 단계 더 나아가, 무엇을 검색할지 스스로 결정하고 여러 소스를 조합해 정리한다.

`sports_agentic_rag.py`는 다음 정보를 묶는다.

- 일정 데이터
- 뉴스 요약
- 부상 리포트

즉, 검색된 조각들을 단순 나열하는 것이 아니라, 주제에 맞게 묶어서 판단 가능한 형태로 정리한다.

### 개념 시각화

```mermaid
flowchart LR
    A["질문"] --> B["에이전트"]
    B --> C["정형 데이터 조회"]
    B --> D["뉴스/문서 검색"]
    C --> E["근거 통합"]
    D --> E
    E --> F["요약 및 추천"]
```

### 실습

```powershell
python ch11_agentic_rag\sports_agentic_rag.py
python ch11_agentic_rag\healthcare_agentic_rag.py
```

### 생각해보기

- 일반 RAG와 Agentic RAG의 차이는 무엇인가?
- 검색 소스가 늘수록 어떤 품질 관리가 필요할까?

---

## 장별 실습 순서 추천

초보자는 다음 순서로 실습하는 것이 좋다.

1. `ch01_intro`
2. `ch06_tool_calling`
3. `ch05_model_tool_state`
4. `ch07_state_memory`
5. `ch08_hitl`
6. `ch09_workflow_vs_autonomous`
7. `ch10_multi_agent`
8. `ch11_agentic_rag`

이 순서는 "도구 사용 -> 상태 유지 -> 사람 승인 -> 자율성 확대" 흐름으로 이어진다.

---

## 통합 미니 프로젝트

### 프로젝트 주제

"스포츠 운영 보조 에이전트" 또는 "헬스케어 예약 보조 에이전트"를 설계하라.

### 요구사항

- 사용자의 질문을 받는다.
- 최소 2개의 tool을 호출한다.
- 상태를 저장한다.
- 외부 발송 전 승인 단계를 둔다.
- 마지막에 요약 리포트를 만든다.

### 설계 예시

```mermaid
flowchart TD
    A["질문 입력"] --> B["의도 분석"]
    B --> C["도구 1 호출"]
    B --> D["도구 2 호출"]
    C --> E["상태 저장"]
    D --> E
    E --> F["초안 생성"]
    F --> G["사람 승인"]
    G --> H["최종 발송 또는 보류"]
```

### 제출 항목

- 실행 파일 1개
- 사용한 tool 설명
- 상태 구조 설명
- 승인 지점 설명
- 개선 아이디어 2개

---

## 핵심 요약

- 챗봇은 말하는 시스템이고, 에이전트는 행동하는 시스템이다.
- 에이전트는 모델만으로 완성되지 않고 도구, 상태, 메모리, 승인 구조가 함께 필요하다.
- 단순한 작업은 LangChain으로 빠르게 만들 수 있고, 복잡한 흐름은 LangGraph가 유리하다.
- 실무에서는 HITL, Workflow, Multi-Agent, Agentic RAG가 매우 중요한 확장 포인트다.

---

## 부록: 빠른 실행 명령어

```powershell
python ch01_intro\sports_agent.py
python ch02_why_agents_now\sports_ops_assistant.py
python ch03_architecture\sports_architecture.py
python ch04_langchain_vs_langgraph\sports_langchain_agent.py
python ch05_model_tool_state\sports_state_demo.py
python ch06_tool_calling\sports_tool_calling.py
python ch07_state_memory\sports_memory_demo.py
python ch08_hitl\sports_hitl_mail.py
python ch09_workflow_vs_autonomous\sports_workflow_vs_autonomous.py
python ch10_multi_agent\sports_multi_agent.py
python ch11_agentic_rag\sports_agentic_rag.py
```

이 교재는 현재 폴더 구조를 그대로 따라가며 읽고 실습할 수 있게 구성되어 있다.  
따라서 각 장을 읽은 뒤 바로 해당 폴더의 예제를 실행해보면 개념과 코드가 자연스럽게 연결된다.
