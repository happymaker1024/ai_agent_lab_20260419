from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_healthcare import (
    get_appointment_info_data,
    get_care_guideline_data,
    get_patient_vitals_data,
)
from common.utils import print_panel


def build_support_summary(patient_name: str) -> str:
    appointments = get_appointment_info_data(patient_name)
    vitals = get_patient_vitals_data(patient_name)
    guide = get_care_guideline_data().splitlines()[0:5]
    lines = [
        f"환자: {patient_name}",
        f"예약 건수: {len(appointments)}",
        f"최신 바이탈: {vitals}",
        "생활관리 가이드 핵심:",
        *guide,
    ]
    return "\n".join(f"- {line}" for line in lines)


if __name__ == "__main__":
    print_panel("2장 헬스케어 보조 시스템", build_support_summary("김민수"))
