"""Chapter 2 examples."""
