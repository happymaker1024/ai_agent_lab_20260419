from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_sports import (
    get_injury_report_data,
    get_player_stats_data,
    get_team_schedule_data,
)
from common.utils import print_panel


def build_ops_report(team_name: str, player_name: str) -> str:
    schedule = get_team_schedule_data(team_name)
    injuries = get_injury_report_data(team_name)
    player_stats = get_player_stats_data(player_name)
    lines = [
        f"팀: {team_name}",
        f"다음 일정 수: {len(schedule)}",
        f"핵심 선수 정보: {player_stats}",
        f"부상 리포트 수: {len(injuries)}",
    ]
    if schedule:
        lines.append(f"첫 경기: {schedule[0]}")
    if injuries:
        lines.append(f"주의 선수: {injuries[0]}")
    return "\n".join(f"- {line}" for line in lines)


if __name__ == "__main__":
    print_panel("2장 스포츠 보조 시스템", build_ops_report("서울 FC", "정우성"))
