"""Chapter 8 examples."""
