from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import ApprovalRequest
from common.utils import print_panel


def main() -> None:
    draft = ApprovalRequest(
        title="생활관리 안내 메시지",
        recipient="김민수",
        message="수분 섭취, 혈압 기록, 예약 준비물을 포함한 안내 메시지입니다.",
    )
    print_panel("8장 헬스케어 HITL", f"{draft.title}\n대상자: {draft.recipient}\n{draft.message}")
    answer = input("메시지를 전송할까요? [y/N]: ").strip().lower()
    draft.approved = answer == "y"
    print("전송 완료" if draft.approved else "의료진 검토 대기")


if __name__ == "__main__":
    main()
