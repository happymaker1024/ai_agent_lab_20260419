from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import ApprovalRequest
from common.utils import print_panel


def main() -> None:
    draft = ApprovalRequest(
        title="경기 요약 메일",
        recipient="coach@seoulfc.example",
        message="서울 FC 다음 경기 일정과 부상자 요약을 발송합니다.",
    )
    print_panel("8장 스포츠 HITL", f"{draft.title}\n수신자: {draft.recipient}\n{draft.message}")
    answer = input("메일을 발송할까요? [y/N]: ").strip().lower()
    draft.approved = answer == "y"
    print("발송 완료" if draft.approved else "사람 검토 후 보류")


if __name__ == "__main__":
    main()
