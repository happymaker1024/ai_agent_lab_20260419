"""Chapter 4 examples."""
