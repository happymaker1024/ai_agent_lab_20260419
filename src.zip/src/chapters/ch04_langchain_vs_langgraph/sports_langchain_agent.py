from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langchain.agents import create_agent
from rich import print

from common.config import ensure_openai_api_key, get_model_name
from common.tools_sports import get_team_schedule, list_soccer_teams


def main() -> None:
    ensure_openai_api_key()
    agent = create_agent(
        model=f"openai:{get_model_name()}",
        tools=[list_soccer_teams, get_team_schedule],
        system_prompt="도구를 사용해 경기 일정을 짧고 정확하게 답하세요.",
    )
    result = agent.invoke(
        {"messages": [{"role": "user", "content": "서울 FC 경기 일정 알려줘"}]}
    )
    print("[bold green]=== LangChain create_agent 예시 ===[/bold green]")
    for msg in result["messages"]:
        if getattr(msg, "type", "") == "ai":
            text = msg.text() if hasattr(msg, "text") else str(msg.content)
            if text:
                print(text)


if __name__ == "__main__":
    main()
