from __future__ import annotations

import sys
from pathlib import Path
from typing import TypedDict

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langgraph.graph import END, StateGraph
from rich import print


class ApprovalState(TypedDict):
    patient_name: str
    draft_message: str
    approved: bool
    result: str


def prepare_message(state: ApprovalState) -> ApprovalState:
    state["draft_message"] = (
        f"{state['patient_name']}님 예약 안내 메시지를 발송할 준비가 되었습니다."
    )
    return state


def wait_for_approval(state: ApprovalState) -> ApprovalState:
    answer = input("메시지를 발송할까요? [y/N]: ").strip().lower()
    state["approved"] = answer == "y"
    return state


def finalize(state: ApprovalState) -> ApprovalState:
    state["result"] = (
        "메시지 발송 완료" if state["approved"] else "승인 대기 상태로 보류"
    )
    return state


def main() -> None:
    graph = StateGraph(ApprovalState)
    graph.add_node("prepare_message", prepare_message)
    graph.add_node("wait_for_approval", wait_for_approval)
    graph.add_node("finalize", finalize)
    graph.set_entry_point("prepare_message")
    graph.add_edge("prepare_message", "wait_for_approval")
    graph.add_edge("wait_for_approval", "finalize")
    graph.add_edge("finalize", END)
    app = graph.compile()
    result = app.invoke(
        {
            "patient_name": "김민수",
            "draft_message": "",
            "approved": False,
            "result": "",
        }
    )
    print("[bold green]=== LangGraph 승인 흐름 ===[/bold green]")
    print(result["draft_message"])
    print(result["result"])


if __name__ == "__main__":
    main()
