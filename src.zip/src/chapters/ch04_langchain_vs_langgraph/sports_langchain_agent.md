# sports_langchain_agent 예제 설명

## 파일

- 대상 코드: `sports_langchain_agent.py`

## 학습 목표

- LangChain의 `create_agent` 기반 빠른 에이전트 구성을 이해한다.
- 간단한 tool agent를 짧은 코드로 만드는 방식을 익힌다.

## 예제 설명

이 예제는 LangChain으로 만든 스포츠 일정 조회 에이전트다.  
핵심은 복잡한 상태 그래프 없이도 에이전트를 빠르게 만들 수 있다는 점이다.

구성 요소는 단순하다.

- 모델
- tool 목록
- system prompt
- 사용자 메시지

## 실행 방법

```powershell
python sports_langchain_agent.py
```

## 코드 포인트

- `create_agent` 사용
- 일정 조회 tool 등록
- 예제 질문을 바로 `invoke`로 실행

## 관찰 포인트

- 빠른 프로토타이핑에 적합하다.
- 복잡한 승인/분기 로직이 필요하면 한계가 생길 수 있다.

## 실습 질문

- 이 예제에 선수 기록 tool을 추가하면 구조가 얼마나 복잡해질까?
- 간단한 에이전트에서는 왜 LangChain이 편리한가?

