# healthcare_langgraph_approval 예제 설명

## 파일

- 대상 코드: `healthcare_langgraph_approval.py`

## 학습 목표

- LangGraph의 상태 기반 흐름 제어 방식을 이해한다.
- 승인 단계를 가진 업무형 에이전트 구조를 배운다.

## 예제 설명

이 예제는 메시지 발송 전 승인 흐름을 그래프로 정의한다.  
흐름은 매우 명시적이다.

1. `prepare_message`
2. `wait_for_approval`
3. `finalize`

각 단계는 상태를 입력받아 수정하고 다음 단계로 넘긴다.

## 실행 방법

```powershell
python healthcare_langgraph_approval.py
```

## 코드 포인트

- `TypedDict`로 상태 구조를 정의한다.
- `StateGraph`에 노드를 추가한다.
- edge를 연결해 순차 실행 흐름을 만든다.

## 관찰 포인트

- 승인, 분기, 재시도처럼 흐름이 중요한 문제에 적합하다.
- 상태 전이가 명확해서 디버깅과 검토가 쉽다.

## 실습 질문

- 승인 거절 시 수정 요청 분기를 추가하려면 어떤 노드가 더 필요할까?
- 이 예제를 LangChain 단일 에이전트로 만들면 어떤 부분이 불명확해질까?

