from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_healthcare import get_appointment_info_data, get_care_guideline_data
from common.utils import print_panel


def workflow_case(patient_name: str) -> str:
    appointments = get_appointment_info_data(patient_name)
    return "\n".join(
        [
            "Workflow 방식",
            f"1. 예약 확인: {len(appointments)}건",
            "2. 예약 정보만 반환",
            "3. 표준 템플릿 종료",
        ]
    )


def autonomous_case(patient_name: str) -> str:
    guide = get_care_guideline_data().splitlines()[0:3]
    return "\n".join(
        [
            "Autonomous 방식",
            "1. 예약 외에 추가 참고 자료 필요 여부 판단",
            *guide,
            "2. 환자 질문에 맞는 생활관리 포인트까지 확장",
        ]
    )


if __name__ == "__main__":
    body = workflow_case("김민수") + "\n\n" + autonomous_case("김민수")
    print_panel("9장 헬스케어 Workflow vs Autonomous", body)
