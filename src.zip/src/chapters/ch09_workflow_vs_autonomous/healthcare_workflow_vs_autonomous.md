# healthcare_workflow_vs_autonomous 예제 설명

## 파일

- 대상 코드: `healthcare_workflow_vs_autonomous.py`

## 학습 목표

- 헬스케어 도메인에서 workflow와 autonomous 차이를 이해한다.
- 예약 정보 반환과 생활관리 확장 안내의 차이를 설명할 수 있다.

## 예제 설명

이 예제는 환자 안내를 두 가지 방식으로 비교한다.

### Workflow 방식

- 예약 확인
- 예약 정보만 반환
- 표준 템플릿 종료

### Autonomous 방식

- 예약 외에 참고 자료 필요 여부 판단
- 가이드라인 일부 탐색
- 생활관리 포인트까지 확장

## 실행 방법

```powershell
python healthcare_workflow_vs_autonomous.py
```

## 코드 포인트

- `workflow_case()`는 예측 가능한 고정 흐름
- `autonomous_case()`는 문맥 확장을 수행

## 관찰 포인트

- 자율 확장은 유용하지만 과도하면 역할 범위를 넘을 수 있다.
- 헬스케어에서는 확장된 안내일수록 검토 기준이 중요하다.

## 실습 질문

- 자율 확장 범위를 어디까지 허용하는 것이 안전할까?
- workflow 결과와 autonomous 결과를 합쳐 혼합형으로 만들 수 있을까?

