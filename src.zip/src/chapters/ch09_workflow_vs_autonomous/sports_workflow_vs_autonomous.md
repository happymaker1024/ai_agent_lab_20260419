# sports_workflow_vs_autonomous 예제 설명

## 파일

- 대상 코드: `sports_workflow_vs_autonomous.py`

## 학습 목표

- 고정 절차형 workflow와 자율형 autonomous 방식의 차이를 이해한다.
- 자율성이 추가되면 어떤 이점과 위험이 생기는지 생각해본다.

## 예제 설명

이 예제는 같은 팀에 대해 두 가지 방식을 비교한다.

### Workflow 방식

- 일정 수집
- 템플릿 작성
- 공유

### Autonomous 방식

- 일정 외에 부상 리포트 필요성까지 스스로 판단
- 추가 조사 수행
- 감독에게 강조할 리스크 정리

## 실행 방법

```powershell
python sports_workflow_vs_autonomous.py
```

## 코드 포인트

- `workflow_report()`는 고정 단계 실행
- `autonomous_report()`는 추가 조사 판단을 포함

## 관찰 포인트

- 자율성은 품질 향상 가능성을 주지만 통제 장치가 필요하다.
- 초기 제품은 workflow부터 시작하는 편이 안전하다.

## 실습 질문

- autonomous 방식에 승인 단계를 추가한다면 어디가 적절할까?
- 어떤 업무는 workflow가 더 낫고 어떤 업무는 autonomous가 더 나을까?

