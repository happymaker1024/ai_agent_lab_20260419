from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_sports import get_injury_report_data, get_team_schedule_data
from common.utils import print_panel


def workflow_report(team_name: str) -> str:
    schedule = get_team_schedule_data(team_name)
    return "\n".join(
        [
            "Workflow 방식",
            f"1. 일정 수집: {len(schedule)}건",
            "2. 템플릿에 맞춰 리포트 작성",
            "3. 지정된 수신자에게 공유",
        ]
    )


def autonomous_report(team_name: str) -> str:
    injuries = get_injury_report_data(team_name)
    return "\n".join(
        [
            "Autonomous 방식",
            "1. 일정 외에 부상 리포트 필요성을 스스로 판단",
            f"2. 추가 조사 결과: 부상 {len(injuries)}건",
            "3. 감독에게 강조할 리스크를 별도 정리",
        ]
    )


if __name__ == "__main__":
    body = workflow_report("서울 FC") + "\n\n" + autonomous_report("서울 FC")
    print_panel("9장 스포츠 Workflow vs Autonomous", body)
