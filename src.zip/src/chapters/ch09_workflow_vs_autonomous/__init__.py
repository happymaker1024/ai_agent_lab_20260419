"""Chapter 9 examples."""
