"""Chapter 7 examples."""
