from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import HealthcareState
from common.utils import print_panel


if __name__ == "__main__":
    state = HealthcareState(bullet_preference=True)
    body = "\n".join(
        [
            "저장된 사용자 선호: 짧은 bullet 요약",
            "다음 응답 형식:",
            "- 예약",
            "- 바이탈",
            "- 생활관리 포인트",
        ]
    )
    print_panel("7장 헬스케어 Memory", body)
