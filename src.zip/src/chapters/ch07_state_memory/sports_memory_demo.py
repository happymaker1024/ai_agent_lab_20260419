from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import SportsState
from common.utils import print_panel


if __name__ == "__main__":
    state = SportsState(preference="EPL 요약 선호")
    body = "\n".join(
        [
            f"저장된 선호: {state.preference}",
            "다음 응답 전략:",
            "- 리그 전체 흐름을 먼저 요약한다.",
            "- 세부 일정은 요청 시 추가한다.",
        ]
    )
    print_panel("7장 스포츠 Memory", body)
