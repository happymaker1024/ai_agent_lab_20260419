from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import ResearchFinding
from common.tools_sports import get_injury_report_data, get_team_schedule_data
from common.utils import print_panel

NEWS = [
    "서울 FC가 최근 압박 강도를 높이며 전방 전개 속도를 개선했다.",
    "주중 경기 대비를 위해 로테이션 가능성이 거론된다.",
]


def build_rag_summary(team_name: str) -> str:
    findings = [
        ResearchFinding("team_report", f"다음 경기 {len(get_team_schedule_data(team_name))}건"),
        ResearchFinding("news", NEWS[0]),
        ResearchFinding("news", NEWS[1]),
        ResearchFinding("team_report", f"부상 리포트 {len(get_injury_report_data(team_name))}건"),
    ]
    return "\n".join(f"- [{item.source}] {item.summary}" for item in findings)


if __name__ == "__main__":
    print_panel("11장 스포츠 Agentic RAG", build_rag_summary("서울 FC"))
