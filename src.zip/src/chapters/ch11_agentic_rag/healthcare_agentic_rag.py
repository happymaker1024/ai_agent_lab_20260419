from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import ResearchFinding
from common.tools_healthcare import (
    get_appointment_info_data,
    get_care_guideline_data,
    get_patient_vitals_data,
)
from common.utils import print_panel


def build_rag_summary(patient_name: str) -> str:
    guideline_lines = get_care_guideline_data().splitlines()[1:4]
    findings = [
        ResearchFinding("appointment", f"예약 {len(get_appointment_info_data(patient_name))}건"),
        ResearchFinding("vitals", get_patient_vitals_data(patient_name)),
        *[ResearchFinding("guideline", line) for line in guideline_lines],
    ]
    return "\n".join(f"- [{item.source}] {item.summary}" for item in findings)


if __name__ == "__main__":
    print_panel("11장 헬스케어 Agentic RAG", build_rag_summary("김민수"))
