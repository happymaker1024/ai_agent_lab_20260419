# agent_eval_dashboard 예제 설명

## 파일

- 대상 코드: `agent_eval_dashboard.py`

## 학습 목표

- 에이전트 평가가 정답 정확도만으로 충분하지 않다는 점을 이해한다.
- 운영형 agent에서 자주 보는 핵심 지표를 익힌다.

## Mermaid로 보는 평가 관점

```mermaid
flowchart TD
    A["Agent Run"] --> B["정답 품질"]
    A --> C["Tool 성공 여부"]
    A --> D["Task completion"]
    A --> E["Approval / Human review"]
    A --> F["Latency / Cost"]
    A --> G["Retry"]
```

## 예제 설명

이 예제는 여러 실행 로그를 합산해 간단한 평가 대시보드를 만든다.

- `Task completion rate`
- `Tool success rate`
- `Approval rate`
- `Retry rate`
- `Latency`
- `Cost`
- `Human review score`

이 지표들은 실제 agent 품질을 훨씬 입체적으로 보여준다.

## 실행 방법

```powershell
python agent_eval_dashboard.py
```

## 코드 포인트

- `AgentRun` 데이터 클래스로 실행 결과를 기록한다.
- 개별 로그를 합산해 운영 지표로 변환한다.
- 사람 검토 점수까지 포함해 자동 평가의 한계를 보완한다.

## 강의 포인트

- 왜 정확도만으로 부족한가:
  task는 맞았지만 비용이 과하거나 retry가 많을 수 있다.
- human review:
  실제 현업 적합성, 안전성, 설명 가능성을 평가하는 데 중요하다.

## 참고 링크

- [Working with evals](https://platform.openai.com/docs/guides/evals)

