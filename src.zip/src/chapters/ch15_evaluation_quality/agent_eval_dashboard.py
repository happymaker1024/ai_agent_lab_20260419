from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


@dataclass
class AgentRun:
    task_completed: bool
    tool_success: bool
    approved: bool
    retries: int
    latency_ms: int
    cost_usd: float
    human_score: int


RUNS = [
    AgentRun(True, True, True, 0, 1800, 0.032, 5),
    AgentRun(True, False, False, 2, 4200, 0.041, 3),
    AgentRun(False, False, False, 3, 5200, 0.038, 2),
    AgentRun(True, True, True, 1, 2400, 0.029, 4),
]


def pct(count: int, total: int) -> str:
    return f"{(count / total) * 100:.1f}%"


def build_report() -> str:
    total = len(RUNS)
    completed = sum(run.task_completed for run in RUNS)
    tool_success = sum(run.tool_success for run in RUNS)
    approvals = sum(run.approved for run in RUNS)
    retries = sum(run.retries for run in RUNS)
    avg_latency = sum(run.latency_ms for run in RUNS) / total
    total_cost = sum(run.cost_usd for run in RUNS)
    avg_human_score = sum(run.human_score for run in RUNS) / total
    lines = [
        "에이전트 평가 대시보드",
        f"- Task completion rate: {pct(completed, total)}",
        f"- Tool success rate: {pct(tool_success, total)}",
        f"- Approval rate: {pct(approvals, total)}",
        f"- Retry rate: {retries / total:.2f}회/실행",
        f"- Average latency: {avg_latency:.0f} ms",
        f"- Total cost: ${total_cost:.3f}",
        f"- Human review score: {avg_human_score:.1f} / 5",
        "",
        "해석",
        "- 정답 정확도만으로는 운영 품질을 설명하기 어렵다.",
        "- tool 실패와 retry 누적은 사용자 경험과 비용을 동시에 악화시킨다.",
        "- approval과 human review는 안전성과 실무 적합성을 보여준다.",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("15장 평가와 품질관리", build_report())

