from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_sports import (
    get_injury_report_data,
    get_player_stats_data,
    get_team_schedule_data,
)
from common.utils import print_panel


def research_agent(team_name: str) -> str:
    return f"Research Agent: {team_name} 일정 {len(get_team_schedule_data(team_name))}건 수집"


def stats_agent(player_name: str) -> str:
    return f"Stats Agent: {get_player_stats_data(player_name)}"


def summary_agent(team_name: str, player_name: str) -> str:
    return "\n".join(
        [
            research_agent(team_name),
            stats_agent(player_name),
            f"Summary Agent: 부상 리포트 {len(get_injury_report_data(team_name))}건까지 통합",
        ]
    )


if __name__ == "__main__":
    print_panel("10장 스포츠 멀티에이전트", summary_agent("서울 FC", "정우성"))
