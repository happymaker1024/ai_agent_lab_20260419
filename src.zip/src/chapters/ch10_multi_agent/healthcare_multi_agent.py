from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.tools_healthcare import get_appointment_info_data, get_patient_vitals_data
from common.utils import print_panel


def intake_agent(patient_name: str) -> str:
    return f"Intake Agent: 예약 {len(get_appointment_info_data(patient_name))}건 확인"


def vitals_agent(patient_name: str) -> str:
    return f"Vitals Agent: {get_patient_vitals_data(patient_name)}"


def care_summary_agent(patient_name: str) -> str:
    return "\n".join(
        [
            intake_agent(patient_name),
            vitals_agent(patient_name),
            "Care Summary Agent: 예약과 바이탈을 합쳐 상담 준비 요약 생성",
        ]
    )


if __name__ == "__main__":
    print_panel("10장 헬스케어 멀티에이전트", care_summary_agent("김민수"))
