"""Chapter 10 examples."""
