# sports_multi_agent 예제 설명

## 파일

- 대상 코드: `sports_multi_agent.py`

## 학습 목표

- 역할 분담형 멀티 에이전트 구조를 이해한다.
- 수집, 분석, 통합을 분리하는 이유를 설명할 수 있다.

## 예제 설명

이 예제는 세 역할로 작업을 나눈다.

- `research_agent`: 일정 수집
- `stats_agent`: 선수 기록 조회
- `summary_agent`: 두 결과와 부상 정보까지 통합

즉, 하나의 거대한 에이전트가 아니라 작은 책임 단위가 협업하는 구조다.

## 실행 방법

```powershell
python sports_multi_agent.py
```

## 코드 포인트

- 각 agent 함수가 명확한 책임을 가진다.
- 마지막 summary 단계에서 여러 결과를 합친다.

## 관찰 포인트

- 역할 분리는 유지보수와 확장에 유리하다.
- coordinator 역할이 커질수록 조정 로직 설계가 중요해진다.

## 실습 질문

- 부상 분석 agent를 별도 함수로 분리하면 어떤 장점이 있을까?
- agent 간 출력 형식을 통일해야 하는 이유는 무엇일까?

