from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


def build_summary() -> str:
    lines = [
        "AI Agent 강의 최종 정리",
        "- 에이전트는 모델이 아니라 시스템이다.",
        "- 최신 설계의 핵심 5요소: 모델, 도구, 상태, 승인/안전, 관측/평가",
        "- 학습 확장 경로:",
        "  1) 단일 Agent",
        "  2) 상태형 Agent",
        "  3) 멀티에이전트",
        "  4) 상호운용 Agent(MCP/A2A)",
        "- 다음 학습 방향: 운영, 평가, 보안, 상호운용 표준을 함께 익히기",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("22장 최종 정리", build_summary())

