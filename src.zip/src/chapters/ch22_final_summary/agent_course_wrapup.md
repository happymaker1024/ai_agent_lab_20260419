# agent_course_wrapup 예제 설명

## 파일

- 대상 코드: `agent_course_wrapup.py`

## 학습 목표

- 강의 전체 구조를 마지막으로 정리한다.
- 에이전트를 시스템 관점으로 보는 이유를 다시 확인한다.
- 이후 학습 경로를 한눈에 정리한다.

## Mermaid로 보는 전체 확장 경로

```mermaid
flowchart LR
    A["단일 Agent"] --> B["상태형 Agent"]
    B --> C["Human Approval / 운영형 Agent"]
    C --> D["멀티에이전트"]
    D --> E["MCP / A2A 기반 상호운용 Agent"]
```

## 예제 설명

이 예제는 1장부터 22장까지의 핵심 메시지를 마지막으로 한 번 더 압축해서 보여준다.

- 에이전트는 모델이 아니라 시스템
- 핵심 5요소는 모델, 도구, 상태, 안전, 관측/평가
- 단일 agent에서 상호운용 agent까지 점진적으로 확장

## 실행 방법

```powershell
python agent_course_wrapup.py
```

## 강의 마무리 포인트

- 이제부터의 agent 설계는 "LLM 하나"가 아니라 "연결된 시스템"으로 생각해야 한다.
- 앞으로의 학습은 MCP, A2A, 운영, 평가, 보안이 함께 가야 한다.

