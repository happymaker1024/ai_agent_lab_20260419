from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


@dataclass
class AgentCard:
    name: str
    url: str
    description: str
    skills: list[str] = field(default_factory=list)


@dataclass
class RemoteAgent:
    card: AgentCard

    def handle(self, task: str) -> str:
        if self.card.name == "research-agent":
            return f"조사 결과: {task} 관련 핵심 근거 3건 수집"
        if self.card.name == "writer-agent":
            return f"초안 작성: 조사 결과를 바탕으로 5문장 요약 작성"
        return f"{self.card.name}: 처리 완료"


def run_demo() -> str:
    research = RemoteAgent(
        AgentCard(
            name="research-agent",
            url="https://agents.example/research",
            description="자료 수집 전용 A2A 에이전트",
            skills=["search", "evidence"],
        )
    )
    writer = RemoteAgent(
        AgentCard(
            name="writer-agent",
            url="https://agents.example/writer",
            description="문서 초안 작성 전용 A2A 에이전트",
            skills=["outline", "draft"],
        )
    )
    discovered = [research.card, writer.card]
    research_result = research.handle("A2A와 MCP 차이 정리")
    writing_result = writer.handle(research_result)
    lines = [
        "발견된 Agent Card",
        *[
            f"- {card.name} @ {card.url} / skills={', '.join(card.skills)}"
            for card in discovered
        ],
        "[협업 흐름]",
        f"1. Root Agent -> research-agent: A2A와 MCP 차이 정리",
        f"2. research-agent -> Root Agent: {research_result}",
        f"3. Root Agent -> writer-agent: {research_result}",
        f"4. writer-agent -> Root Agent: {writing_result}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("13장 A2A 상호운용성 데모", run_demo())

