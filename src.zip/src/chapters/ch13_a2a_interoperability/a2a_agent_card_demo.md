# a2a_agent_card_demo 예제 설명

## 파일

- 대상 코드: `a2a_agent_card_demo.py`

## 학습 목표

- A2A가 무엇인지 이해한다.
- MCP와 A2A의 차이를 설명할 수 있다.
- Agent Card 기반 발견과 협업 흐름을 파악한다.

## Mermaid로 보는 흐름

```mermaid
flowchart LR
    A["Root Agent"] --> B["Agent Discovery"]
    B --> C["Agent Card: research-agent"]
    B --> D["Agent Card: writer-agent"]
    A --> C
    C --> A
    A --> D
    D --> A
```

## 예제 설명

이 예제는 A2A의 핵심 개념인 Agent Card와 원격 에이전트 협업을 간단히 흉내 낸다.

- Root Agent가 Agent Card를 보고 상대 에이전트를 발견한다.
- research-agent에 조사 작업을 위임한다.
- writer-agent에 정리 작업을 위임한다.

즉, A2A는 "서로 다른 에이전트 시스템 간 통신과 협업"에 초점을 둔다.

## MCP와 A2A 차이

```mermaid
flowchart TD
    A["MCP"] --> B["모델이 외부 도구/리소스/프롬프트 사용"]
    C["A2A"] --> D["에이전트가 다른 에이전트와 통신 및 협업"]
```

- MCP: 도구와 문맥 연결 표준
- A2A: 에이전트 간 발견, 통신, 협업 표준

## 실행 방법

```powershell
python a2a_agent_card_demo.py
```

## 코드 포인트

- `AgentCard`는 에이전트의 공개 명세 역할을 한다.
- `RemoteAgent`는 A2A로 접근 가능한 외부 에이전트를 단순화한 모델이다.
- 협업 단계를 출력해서 discovery와 delegation 흐름을 눈으로 볼 수 있게 했다.

## 공식 자료 메모

- Google은 A2A를 2025년 4월 9일 발표했다.
- 공식 자료는 Agent Card와 agent discovery/communication을 핵심 요소로 소개한다.
- A2A는 MCP를 대체하기보다 보완하는 상호운용 프로토콜로 보는 것이 자연스럽다.

## 참고 링크

- [Announcing the Agent2Agent Protocol (A2A) - April 9, 2025](https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/)
- [A2A Introduction](https://google.github.io/adk-docs/a2a/intro/)
- [A2A with ADK](https://google.github.io/adk-docs/a2a/)

