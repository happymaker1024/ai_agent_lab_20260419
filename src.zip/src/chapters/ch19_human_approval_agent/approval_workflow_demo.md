# approval_workflow_demo 예제 설명

## 파일

- 대상 코드: `approval_workflow_demo.py`

## 학습 목표

- Human Approval Agent의 전체 흐름을 이해한다.
- 초안 생성, 검토 요청, 승인/반려, 재수정, 최종 확정을 상태 그래프로 구현하는 법을 익힌다.

## Mermaid로 보는 흐름

```mermaid
flowchart TD
    A["초안 생성"] --> B["사람 검토 요청"]
    B -->|approve| C["최종 확정"]
    B -->|reject| D["초안 수정"]
    D --> E["재검토"]
    E --> F["최종 확정"]
```

## 예제 설명

이 예제는 실습 3에 해당하는 Human Approval Agent다.

- 초안 생성
- 첫 번째 승인 요청
- 반려 시 수정본 작성
- 두 번째 승인 요청
- 최종 확정

승인 흐름이 길어질수록 상태와 checkpoint가 왜 중요한지도 함께 보여준다.

## 실행 방법

```powershell
python approval_workflow_demo.py
```

## 코드 포인트

- `interrupt()`를 두 번 사용해 실제 사람 검토 단계를 흉내 낸다.
- `reject`가 들어오면 수정본을 만든 뒤 다시 검토를 요청한다.
- 모든 단계가 같은 `thread_id` 위에서 이어진다.

## 실습 질문

- 반려 사유를 남기려면 상태에 어떤 필드가 더 필요할까?
- 특정 요청은 첫 승인만으로 끝내고, 어떤 요청은 2단계 검토가 필요할까?

## 참고 링크

- [LangGraph Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)
- [LangGraph Persistence](https://docs.langchain.com/oss/python/langgraph/persistence)

