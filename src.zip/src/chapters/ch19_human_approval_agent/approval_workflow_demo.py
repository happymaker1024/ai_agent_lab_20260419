from __future__ import annotations

import sys
from pathlib import Path
from typing import TypedDict

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from common.utils import print_panel


class ApprovalState(TypedDict):
    request: str
    draft: str
    decision: str
    final_message: str


def create_draft(state: ApprovalState) -> ApprovalState:
    state["draft"] = f"[초안] {state['request']} 안내 메시지 초안"
    return state


def request_review(state: ApprovalState) -> ApprovalState:
    state["decision"] = str(
        interrupt(
            {
                "kind": "human_approval",
                "draft": state["draft"],
                "options": ["approve", "reject"],
            }
        )
    )
    return state


def revise_or_finalize(state: ApprovalState) -> ApprovalState:
    if state["decision"] == "reject":
        state["draft"] = f"[수정본] {state['request']} 핵심 정보만 남겨 짧게 재작성"
        state["decision"] = str(
            interrupt(
                {
                    "kind": "second_review",
                    "draft": state["draft"],
                    "options": ["approve"],
                }
            )
        )
    state["final_message"] = f"최종 확정: {state['draft']}"
    return state


def main() -> None:
    graph = StateGraph(ApprovalState)
    graph.add_node("create_draft", create_draft)
    graph.add_node("request_review", request_review)
    graph.add_node("revise_or_finalize", revise_or_finalize)
    graph.add_edge(START, "create_draft")
    graph.add_edge("create_draft", "request_review")
    graph.add_edge("request_review", "revise_or_finalize")
    graph.add_edge("revise_or_finalize", END)
    app = graph.compile(checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "approval-thread-19"}}

    first = app.invoke(
        {
            "request": "환자 예약 변경",
            "draft": "",
            "decision": "",
            "final_message": "",
        },
        config=config,
    )
    print_panel(
        "19장 Human Approval Agent - 1차",
        "\n".join(
            [
                f"- draft: {first['draft']}",
                f"- interrupt: {first['__interrupt__'][0].value}",
            ]
        ),
    )

    second = app.invoke(Command(resume="reject"), config=config)
    revised_payload = second["__interrupt__"][0].value
    print_panel(
        "19장 Human Approval Agent - 반려 후",
        "\n".join(
            [
                f"- revised draft: {revised_payload['draft']}",
                f"- interrupt: {revised_payload}",
            ]
        ),
    )

    third = app.invoke(Command(resume="approve"), config=config)
    print_panel(
        "19장 Human Approval Agent - 최종",
        "\n".join(
            [
                f"- decision: {third['decision']}",
                f"- final_message: {third['final_message']}",
            ]
        ),
    )


if __name__ == "__main__":
    main()
