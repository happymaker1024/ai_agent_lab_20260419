from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from openai import OpenAI
from rich import print

from common.config import ensure_openai_api_key, get_model_name

TEAM_SCHEDULE = {
    "서울 FC": "2026-04-25 vs 부산 유나이티드",
    "부산 유나이티드": "2026-04-27 vs 수원 블루윈즈",
}

TOOLS = [
    {
        "type": "function",
        "name": "get_team_schedule",
        "description": "축구 팀의 다음 경기 일정을 조회한다.",
        "parameters": {
            "type": "object",
            "properties": {
                "team_name": {
                    "type": "string",
                    "description": "조회할 축구 팀 이름",
                }
            },
            "required": ["team_name"],
            "additionalProperties": False,
        },
        "strict": True,
    }
]

RESPONSE_FORMAT = {
    "format": {
        "type": "json_schema",
        "name": "agent_answer",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "team_name": {"type": "string"},
                "answer": {"type": "string"},
                "used_tool": {"type": "boolean"},
            },
            "required": ["team_name", "answer", "used_tool"],
            "additionalProperties": False,
        },
    }
}


def get_team_schedule(team_name: str) -> str:
    return TEAM_SCHEDULE.get(team_name, f"{team_name} 일정 데이터가 없습니다.")


def main() -> None:
    ensure_openai_api_key()
    client = OpenAI()
    model = get_model_name()
    user_input = input("질문을 입력하세요 [예: 서울 FC 다음 경기 알려줘]: ").strip()
    user_input = user_input or "서울 FC 다음 경기 알려줘"

    first = client.responses.create(
        model=model,
        input=user_input,
        tools=TOOLS,
        instructions=(
            "너는 가장 단순한 스포츠 에이전트다. "
            "일정 질문에는 도구를 우선 사용하고, 마지막 답은 JSON schema에 맞춰 반환한다."
        ),
    )

    follow_up_items = list(first.output)
    used_tool = False
    team_name = "알 수 없음"
    for item in first.output:
        if item.type != "function_call":
            continue
        used_tool = True
        args = json.loads(item.arguments)
        team_name = args["team_name"]
        tool_output = get_team_schedule(team_name)
        follow_up_items.append(
            {
                "type": "function_call_output",
                "call_id": item.call_id,
                "output": json.dumps({"team_name": team_name, "schedule": tool_output}),
            }
        )

    final = client.responses.create(
        model=model,
        input=follow_up_items,
        tools=TOOLS,
        instructions=(
            "반드시 JSON으로 응답한다. "
            "answer에는 한국어 자연어 설명을 담고, used_tool에는 도구 사용 여부를 넣는다."
        ),
        text=RESPONSE_FORMAT,
    )

    print("\n[bold green]=== 17장 가장 단순한 Agent ===[/bold green]")
    print(final.output_text)
    if not used_tool:
        print("[yellow]참고: 이번 실행에서는 tool call이 발생하지 않았습니다.[/yellow]")


if __name__ == "__main__":
    main()

