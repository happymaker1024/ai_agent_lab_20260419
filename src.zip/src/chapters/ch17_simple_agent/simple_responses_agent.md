# simple_responses_agent 예제 설명

## 파일

- 대상 코드: `simple_responses_agent.py`

## 학습 목표

- OpenAI Responses API로 가장 단순한 agent를 만드는 흐름을 익힌다.
- 도구 1개 연결, 질의응답, tool call, structured output까지 한 번에 이해한다.

## Mermaid로 보는 흐름

```mermaid
sequenceDiagram
    participant U as User
    participant M as Responses API
    participant T as get_team_schedule
    U->>M: 서울 FC 다음 경기 알려줘
    M->>T: team_name=서울 FC
    T-->>M: 2026-04-25 vs 부산 유나이티드
    M-->>U: JSON structured output
```

## 예제 설명

이 예제는 실습 1에 해당하는 가장 작은 agent 패턴이다.

- 모델 연결
- tool 1개 등록
- 도구 호출 결과 반영
- 최종 응답을 structured output으로 반환

즉, "모델 + 도구 + JSON 응답"의 가장 기본 조합을 직접 보여준다.

## 실행 방법

```powershell
python simple_responses_agent.py
```

## 코드 포인트

- `OpenAI().responses.create(...)`를 사용한다.
- `tools`에 function schema를 정의한다.
- 첫 번째 응답에서 `function_call`을 찾아 직접 실행한다.
- 두 번째 응답에서 `text.format`의 `json_schema`를 사용해 structured output을 받는다.

## 실습 질문

- `get_team_schedule` 대신 다른 도구를 추가한다면 어떤 schema가 필요할까?
- structured output이 없으면 후속 시스템 연결이 왜 어려워질까?

## 참고 링크

- [Responses API](https://platform.openai.com/docs/api-reference/responses/retrieve)
- [Function calling](https://platform.openai.com/docs/guides/function-calling?api-mode=responses)
- [Structured outputs](https://platform.openai.com/docs/guides/structured-outputs?lang=javascript)

