from __future__ import annotations

import sys
from pathlib import Path
from typing import TypedDict

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from common.utils import print_panel


class LessonState(TypedDict):
    topic: str
    outline: str
    feedback: str
    final_note: str


def draft_outline(state: LessonState) -> LessonState:
    state["outline"] = f"{state['topic']} 실습 개요 / 목표 / 확인 질문"
    return state


def review_gate(state: LessonState) -> LessonState:
    feedback = interrupt(
        {
            "kind": "review",
            "outline": state["outline"],
            "question": "승인하려면 approve, 수정하려면 revise 입력",
        }
    )
    state["feedback"] = str(feedback)
    return state


def finalize_note(state: LessonState) -> LessonState:
    if state["feedback"] == "revise":
        state["final_note"] = f"수정본: {state['outline']} + 예제를 한 단계 더 자세히 설명"
    else:
        state["final_note"] = f"확정본: {state['outline']}"
    return state


def main() -> None:
    graph = StateGraph(LessonState)
    graph.add_node("draft_outline", draft_outline)
    graph.add_node("review_gate", review_gate)
    graph.add_node("finalize_note", finalize_note)
    graph.add_edge(START, "draft_outline")
    graph.add_edge("draft_outline", "review_gate")
    graph.add_edge("review_gate", "finalize_note")
    graph.add_edge("finalize_note", END)

    app = graph.compile(checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "lesson-thread-18"}}
    first = app.invoke(
        {
            "topic": "LangGraph 상태형 Agent",
            "outline": "",
            "feedback": "",
            "final_note": "",
        },
        config=config,
    )

    if "__interrupt__" in first:
        body = "\n".join(
            [
                "1차 실행 결과",
                f"- outline: {first['outline']}",
                f"- interrupt payload: {first['__interrupt__'][0].value}",
                "",
                "체크포인트를 유지한 채 resume 수행",
            ]
        )
        print_panel("18장 LangGraph 상태형 Agent - 1차", body)

    second = app.invoke(Command(resume="approve"), config=config)
    body = "\n".join(
        [
            "재개 후 결과",
            f"- feedback: {second['feedback']}",
            f"- final_note: {second['final_note']}",
        ]
    )
    print_panel("18장 LangGraph 상태형 Agent - 재개", body)


if __name__ == "__main__":
    main()

