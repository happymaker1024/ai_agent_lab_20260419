# langgraph_stateful_demo 예제 설명

## 파일

- 대상 코드: `langgraph_stateful_demo.py`

## 학습 목표

- LangGraph 기반 상태형 agent의 기본 구조를 이해한다.
- `state`, `node`, `edge`, `checkpoint`, `interrupt`가 어떻게 연결되는지 파악한다.

## Mermaid로 보는 흐름

```mermaid
flowchart TD
    A["START"] --> B["draft_outline"]
    B --> C["review_gate (interrupt)"]
    C --> D["checkpoint 저장"]
    D --> E["resume"]
    E --> F["finalize_note"]
    F --> G["END"]
```

## 예제 설명

이 예제는 실습 2에 해당하는 LangGraph 상태형 agent의 최소 버전이다.

- `LessonState`로 상태 정의
- `draft_outline`, `review_gate`, `finalize_note` 노드 구성
- `InMemorySaver`로 checkpoint 적용
- `interrupt()`로 중단 후 `Command(resume=...)` 재개

즉, "상태를 가진 흐름형 agent"를 가장 짧게 보여주는 예제다.

## 실행 방법

```powershell
python langgraph_stateful_demo.py
```

## 코드 포인트

- `StateGraph`로 상태 그래프를 구성한다.
- `InMemorySaver`가 super-step마다 checkpoint를 유지한다.
- `interrupt()`는 외부 입력을 기다리기 위해 실행을 멈춘다.
- `Command(resume="approve")`로 같은 thread에서 이어서 실행한다.

## 실습 질문

- 승인 대신 `revise`를 resume하면 결과가 어떻게 달라질까?
- checkpoint가 없다면 interrupt 이후 왜 재개가 어려울까?

## 참고 링크

- [LangGraph Persistence](https://docs.langchain.com/oss/python/langgraph/persistence)
- [LangGraph Interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)

