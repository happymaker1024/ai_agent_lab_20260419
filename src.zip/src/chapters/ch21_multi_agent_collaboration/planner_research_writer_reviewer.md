# planner_research_writer_reviewer 예제 설명

## 파일

- 대상 코드: `planner_research_writer_reviewer.py`

## 학습 목표

- 실습 5의 멀티에이전트 협업 구조를 이해한다.
- Planner, Research, Writer, Reviewer의 역할 분리를 익힌다.

## Mermaid로 보는 흐름

```mermaid
flowchart LR
    A["Planner Agent"] --> B["Research Agent"]
    B --> C["Writer Agent"]
    C --> D["Reviewer Agent"]
    D --> E["결과 합성"]
```

## 예제 설명

이 예제는 강의안 작성 작업을 멀티에이전트로 나눠 처리한다.

- Planner Agent: 작업 분해
- Research Agent: 근거 수집
- Writer Agent: 초안 작성
- Reviewer Agent: 품질 점검
- 결과 합성: 최종 산출물 정리

즉, 하나의 agent가 모든 역할을 혼자 처리하지 않고, 책임을 나눠 협업한다.

## 실행 방법

```powershell
python planner_research_writer_reviewer.py
```

## 코드 포인트

- 역할별 함수를 분리해 agent 역할을 명확히 했다.
- 출력이 다음 agent 입력으로 이어지는 파이프라인 구조다.
- 마지막 `결과 합성` 단계가 실제 협업 결과물을 정리한다.

## 실습 질문

- Reviewer가 발견한 문제를 Writer에게 다시 보내는 루프를 넣으면 구조가 어떻게 달라질까?
- Planner가 작업 난이도에 따라 agent 수를 동적으로 바꾸게 할 수 있을까?

