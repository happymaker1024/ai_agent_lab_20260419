from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


def planner_agent(topic: str) -> str:
    return f"Planner Agent: {topic}에 대해 조사 -> 초안 -> 검토 순서로 작업 분해"


def research_agent(topic: str) -> str:
    return f"Research Agent: {topic} 핵심 근거 3건과 사례 2건 정리"


def writer_agent(research: str) -> str:
    return f"Writer Agent: '{research}'를 바탕으로 1페이지 초안 작성"


def reviewer_agent(draft: str) -> str:
    return f"Reviewer Agent: '{draft}'의 구조와 근거 연결성을 점검"


def run_demo(topic: str) -> str:
    plan = planner_agent(topic)
    research = research_agent(topic)
    draft = writer_agent(research)
    review = reviewer_agent(draft)
    final = "결과 합성: 계획, 조사, 초안, 리뷰를 반영한 최종 문서 완성"
    return "\n".join([plan, research, draft, review, final])


if __name__ == "__main__":
    print_panel("21장 멀티에이전트 협업", run_demo("AI Agent 강의안 작성"))

