"""Chapter 5 examples."""
