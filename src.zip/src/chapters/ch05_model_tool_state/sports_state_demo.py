from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import SportsState
from common.tools_sports import get_player_stats_data
from common.utils import print_panel


def run_demo() -> str:
    state = SportsState()
    first_answer = get_player_stats_data("정우성")
    state.last_player = "정우성"
    state.notes.append("사용자가 득점과 도움을 먼저 확인했다.")
    follow_up = f"이전 조회 선수는 {state.last_player}입니다. 재질문에 맥락을 이어갑니다."
    return "\n".join([first_answer, follow_up, *state.notes])


if __name__ == "__main__":
    print_panel("5장 스포츠 상태 데모", run_demo())
