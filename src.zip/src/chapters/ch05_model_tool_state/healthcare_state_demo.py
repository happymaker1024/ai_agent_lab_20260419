from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.models import HealthcareState
from common.tools_healthcare import get_patient_vitals_data
from common.utils import print_panel


def run_demo() -> str:
    state = HealthcareState(last_patient="김민수")
    vitals = get_patient_vitals_data(state.last_patient)
    state.latest_vitals_summary = vitals
    state.notes.append("다음 질문에서도 최신 바이탈 요약을 재사용한다.")
    return "\n".join([state.latest_vitals_summary, *state.notes])


if __name__ == "__main__":
    print_panel("5장 헬스케어 상태 데모", run_demo())
