from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from common.utils import print_panel


@dataclass
class MCPTool:
    name: str
    description: str


@dataclass
class MCPResource:
    uri: str
    description: str
    content: str


@dataclass
class MCPPrompt:
    name: str
    description: str
    template: str


@dataclass
class MCPServer:
    name: str
    tools: list[MCPTool] = field(default_factory=list)
    resources: list[MCPResource] = field(default_factory=list)
    prompts: list[MCPPrompt] = field(default_factory=list)

    def list_tools(self) -> list[str]:
        return [f"{tool.name}: {tool.description}" for tool in self.tools]

    def list_resources(self) -> list[str]:
        return [f"{resource.uri}: {resource.description}" for resource in self.resources]

    def list_prompts(self) -> list[str]:
        return [f"{prompt.name}: {prompt.description}" for prompt in self.prompts]

    def read_resource(self, uri: str) -> str:
        for resource in self.resources:
            if resource.uri == uri:
                return resource.content
        raise KeyError(uri)

    def get_prompt(self, name: str, **kwargs: str) -> str:
        for prompt in self.prompts:
            if prompt.name == name:
                return prompt.template.format(**kwargs)
        raise KeyError(name)

    def call_tool(self, name: str, **kwargs: str) -> str:
        if name == "lookup_team_schedule":
            team_name = kwargs["team_name"]
            return f"{team_name}의 다음 경기: 2026-04-25 vs 부산 유나이티드"
        raise KeyError(name)


def build_demo() -> str:
    server = MCPServer(
        name="sports-mcp",
        tools=[MCPTool("lookup_team_schedule", "팀의 다음 경기 일정을 조회한다.")],
        resources=[
            MCPResource(
                "resource://teams/seoul-fc",
                "서울 FC 소개 문서",
                "서울 FC는 강한 압박과 빠른 전환을 강점으로 하는 팀이다.",
            )
        ],
        prompts=[
            MCPPrompt(
                "coach_brief",
                "감독 브리핑 초안을 만든다.",
                "{team_name} 감독 브리핑: {schedule} / 참고: {resource_summary}",
            )
        ],
    )

    tools = server.list_tools()
    resources = server.list_resources()
    prompts = server.list_prompts()
    resource_summary = server.read_resource("resource://teams/seoul-fc")
    schedule = server.call_tool("lookup_team_schedule", team_name="서울 FC")
    brief = server.get_prompt(
        "coach_brief",
        team_name="서울 FC",
        schedule=schedule,
        resource_summary=resource_summary,
    )
    lines = [
        "MCP 서버 연결 성공",
        "[Tools]",
        *[f"- {item}" for item in tools],
        "[Resources]",
        *[f"- {item}" for item in resources],
        "[Prompts]",
        *[f"- {item}" for item in prompts],
        "[Resource Read]",
        resource_summary,
        "[Tool Call]",
        schedule,
        "[Prompt Render]",
        brief,
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print_panel("12장 MCP 개요 데모", build_demo())

