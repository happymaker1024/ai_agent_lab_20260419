# mcp_overview_demo 예제 설명

## 파일

- 대상 코드: `mcp_overview_demo.py`

## 학습 목표

- MCP가 단순 함수 호출보다 넓은 상호운용 계층임을 이해한다.
- `tools`, `resources`, `prompts`의 역할 차이를 설명할 수 있다.
- MCP의 서버-클라이언트 연결 개념을 실습형으로 확인한다.

## Mermaid로 보는 흐름

```mermaid
flowchart LR
    A["Agent Client"] --> B["MCP Server"]
    B --> C["Tools"]
    B --> D["Resources"]
    B --> E["Prompts"]
    C --> F["외부 동작 실행"]
    D --> G["문맥 데이터 제공"]
    E --> H["재사용 가능한 프롬프트 템플릿"]
```

## 예제 설명

이 예제는 원격 네트워크 서버 대신 로컬 클래스 형태로 MCP 구조를 흉내 낸다.

- `list_tools()`로 도구 목록 확인
- `read_resource()`로 문맥 리소스 읽기
- `get_prompt()`로 템플릿 프롬프트 조합
- `call_tool()`로 실제 동작 실행

핵심은 MCP가 "도구만 주는 프로토콜"이 아니라, 문맥과 프롬프트까지 함께 노출하는 표준이라는 점이다.

## 실행 방법

```powershell
python mcp_overview_demo.py
```

## 코드 포인트

- `MCPTool`, `MCPResource`, `MCPPrompt`를 분리해 모델링했다.
- `MCPServer`가 서버 역할을 맡고, 호출자는 클라이언트처럼 동작한다.
- 하나의 예제 안에서 tool call, resource read, prompt render를 모두 보여준다.

## 강의 포인트

- 왜 MCP가 중요한가:
  외부 시스템 연결을 표준화해 도구와 문맥을 일관되게 다룰 수 있다.
- 최소 실습 범위:
  tool 하나, resource 하나, prompt 하나를 가진 서버를 읽고 호출해보는 것.

## 공식 자료 메모

- MCP 공식 명세는 서버 측 핵심 요소를 `tools`, `resources`, `prompts`로 설명한다.
- 아키텍처 문서는 host-client-server 구조를 설명한다.

## 참고 링크

- [MCP Tools Spec](https://modelcontextprotocol.io/specification/2025-03-26/server/tools)
- [MCP Resources Spec](https://modelcontextprotocol.io/specification/2025-11-25/server/resources)
- [MCP Prompts Spec](https://modelcontextprotocol.io/specification/2025-11-25/server/prompts)
- [MCP Architecture](https://modelcontextprotocol.io/specification/2024-11-05/architecture/index)

