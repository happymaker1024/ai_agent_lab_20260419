from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
from rich.console import Console
from rich.panel import Panel

from common.config import DATA_DIR

console = Console()


def bootstrap_project(current_file: str) -> Path:
    root = Path(current_file).resolve().parents[1]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    return root


def read_csv(*parts: str) -> pd.DataFrame:
    path = DATA_DIR.joinpath(*parts)
    return pd.read_csv(path)


def read_text(*parts: str) -> str:
    path = DATA_DIR.joinpath(*parts)
    return path.read_text(encoding="utf-8")


def print_panel(title: str, body: str) -> None:
    console.print(Panel(body, title=title, expand=False))


def bullet_list(lines: list[str]) -> str:
    return "\n".join(f"- {line}" for line in lines)
