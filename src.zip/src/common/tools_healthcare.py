from __future__ import annotations

from langchain.tools import tool

from common.utils import read_csv, read_text


def list_patients_data() -> list[str]:
    df = read_csv("healthcare", "patients_mock.csv")
    return df["name"].tolist()


def get_appointment_info_data(patient_name: str) -> list[str]:
    patients = read_csv("healthcare", "patients_mock.csv")
    appts = read_csv("healthcare", "appointments_mock.csv")
    target = patients[patients["name"] == patient_name]
    if target.empty:
        return []
    patient_id = target.iloc[0]["patient_id"]
    rows = appts[appts["patient_id"] == patient_id].sort_values("date")
    return [
        f"{r['date']} | 진료과: {r['department']} | 상태: {r['status']}"
        for _, r in rows.iterrows()
    ]


def get_patient_vitals_data(patient_name: str) -> str:
    patients = read_csv("healthcare", "patients_mock.csv")
    vitals = read_csv("healthcare", "vitals_mock.csv")
    target = patients[patients["name"] == patient_name]
    if target.empty:
        return f"'{patient_name}' 환자를 찾지 못했습니다."
    patient_id = target.iloc[0]["patient_id"]
    rows = vitals[vitals["patient_id"] == patient_id].sort_values("recorded_at")
    if rows.empty:
        return f"{patient_name} 환자의 바이탈 정보가 없습니다."
    latest = rows.iloc[-1]
    return (
        f"{patient_name} 최신 바이탈 | 혈압: {latest['blood_pressure']} | "
        f"심박수: {latest['heart_rate']} | 체온: {latest['temperature_c']}C | "
        f"메모: {latest['note']}"
    )


def get_care_guideline_data() -> str:
    return read_text("healthcare", "care_guidelines.md")


@tool
def list_patients() -> str:
    """예약 데이터에 등록된 환자 이름 목록을 보여줍니다."""
    return "등록 환자: " + ", ".join(list_patients_data())


@tool
def get_appointment_info(patient_name: str) -> str:
    """특정 환자의 예약 정보를 조회합니다."""
    rows = get_appointment_info_data(patient_name)
    if not rows:
        return f"'{patient_name}' 환자의 예약을 찾지 못했습니다."
    return f"{patient_name} 예약 정보\n" + "\n".join(f"- {line}" for line in rows)


@tool
def get_patient_vitals(patient_name: str) -> str:
    """특정 환자의 최신 바이탈을 조회합니다."""
    return get_patient_vitals_data(patient_name)


@tool
def get_care_guideline() -> str:
    """생활관리 안내 가이드를 조회합니다."""
    return get_care_guideline_data()
