from __future__ import annotations

from langchain.tools import tool

from common.utils import read_csv


def list_soccer_teams_data() -> list[str]:
    df = read_csv("sports", "teams.csv")
    return df["team_name"].tolist()


def get_team_schedule_data(team_name: str) -> list[str]:
    matches = read_csv("sports", "matches.csv")
    rows = matches[
        (matches["home_team"] == team_name) | (matches["away_team"] == team_name)
    ].sort_values("date")
    return [
        f"{r['date']} | {r['home_team']} vs {r['away_team']} | 장소: {r['stadium']}"
        for _, r in rows.iterrows()
    ]


def get_player_stats_data(player_name: str) -> str:
    players = read_csv("sports", "players.csv")
    row = players[players["player_name"] == player_name]
    if row.empty:
        return f"'{player_name}' 선수 정보를 찾지 못했습니다."
    player = row.iloc[0]
    return (
        f"{player['player_name']} | 팀: {player['team_name']} | 포지션: {player['position']} | "
        f"득점: {player['goals']} | 도움: {player['assists']} | 출전: {player['appearances']}"
    )


def get_injury_report_data(team_name: str) -> list[str]:
    injuries = read_csv("sports", "injury_reports.csv")
    rows = injuries[injuries["team_name"] == team_name]
    return [
        f"{r['player_name']} | 상태: {r['status']} | 복귀예상: {r['return_eta']}"
        for _, r in rows.iterrows()
    ]


@tool
def list_soccer_teams() -> str:
    """등록된 축구 팀 목록을 보여줍니다."""
    return "등록 팀: " + ", ".join(list_soccer_teams_data())


@tool
def get_team_schedule(team_name: str) -> str:
    """특정 축구 팀의 경기 일정을 조회합니다."""
    if team_name not in list_soccer_teams_data():
        return f"'{team_name}' 팀을 찾지 못했습니다."
    rows = get_team_schedule_data(team_name)
    return f"{team_name} 경기 일정\n" + "\n".join(f"- {line}" for line in rows)


@tool
def get_player_stats(player_name: str) -> str:
    """특정 선수의 기록을 조회합니다."""
    return get_player_stats_data(player_name)


@tool
def get_injury_report(team_name: str) -> str:
    """특정 팀의 부상 리포트를 조회합니다."""
    rows = get_injury_report_data(team_name)
    if not rows:
        return f"{team_name} 부상 리포트가 없습니다."
    return f"{team_name} 부상 리포트\n" + "\n".join(f"- {line}" for line in rows)
