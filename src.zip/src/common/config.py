from __future__ import annotations

import os
from getpass import getpass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / "data"
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-nano")


def load_environment() -> None:
    load_dotenv(ROOT_DIR / ".env", override=True)


def ensure_openai_api_key(interactive: bool = True) -> str:
    load_environment()
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if api_key and api_key != "your_api_key_here":
        return api_key
    if not interactive:
        raise RuntimeError("OPENAI_API_KEY가 없습니다. .env 파일을 확인하세요.")

    api_key = getpass(
        "OPENAI_API_KEY가 없습니다. OpenAI API 키를 입력하세요: "
    ).strip()
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY가 설정되지 않았습니다.")
    os.environ["OPENAI_API_KEY"] = api_key
    return api_key


def get_model_name() -> str:
    load_environment()
    return os.getenv("OPENAI_MODEL", DEFAULT_MODEL)
