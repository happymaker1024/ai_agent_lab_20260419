from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class SportsState:
    last_team: str | None = None
    last_player: str | None = None
    preference: str = "기본"
    notes: list[str] = field(default_factory=list)


@dataclass
class HealthcareState:
    last_patient: str | None = None
    bullet_preference: bool = True
    latest_vitals_summary: str | None = None
    notes: list[str] = field(default_factory=list)


@dataclass
class ApprovalRequest:
    title: str
    recipient: str
    message: str
    approved: bool = False


@dataclass
class ResearchFinding:
    source: Literal["team_report", "news", "guideline", "appointment", "vitals"]
    summary: str
