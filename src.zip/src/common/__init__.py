"""Shared helpers for the AI agent lab."""
